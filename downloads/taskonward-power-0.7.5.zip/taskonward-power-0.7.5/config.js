globalThis.MEMORY_V5_POWER_CONFIG = {
  apiBase: "https://memory-v5-beta.8084867.workers.dev",
  resource: "https://memory-v5-beta.8084867.workers.dev/mcp",
  authIssuer: "https://select-venue-33.authkit.app",
  oauthClientId: "client_01M3RRDPBAYXZT1N8X9JX2JNKW",
  scopes: ["openid", "profile", "email", "offline_access"]
};
