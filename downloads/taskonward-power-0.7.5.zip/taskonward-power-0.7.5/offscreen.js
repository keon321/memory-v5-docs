chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.target !== "offscreen" || message?.type !== "OFFSCREEN_COPY") {
    return false;
  }

  (async () => {
    const text = String(message.text || "");
    if (!text) throw new Error("clipboard_text_missing");

    try {
      await navigator.clipboard.writeText(text);
      return { ok: true };
    } catch {}

    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    Object.assign(area.style, {
      position: "fixed",
      left: "-9999px",
      top: "0",
    });
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand("copy");
    area.remove();
    if (!ok) throw new Error("clipboard_copy_failed");
    return { ok: true };
  })()
    .then(sendResponse)
    .catch((error) => sendResponse({
      ok: false,
      error: String(error?.message || error),
    }));

  return true;
});
