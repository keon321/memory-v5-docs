importScripts("config.js");

const CONFIG = globalThis.MEMORY_V5_POWER_CONFIG;
const AUTH_KEY = "memory_v5_power_auth";
const DIAG_KEY = "memory_v5_power_last_diag";
const BACKEND_HEALTH_KEY = "memory_v5_backend_health";
const AUTO_BUDGET_KEY = "memory_v5_auto_request_budget";
const BINDING_PREFIX = "memory_v5_binding:";
const OUTBOX_PREFIX = "memory_v5_local_outbox:";
const SAVE_BOUNDARY_PREFIX = "memory_v5_save_boundary:";
const PENDING_TAB_PREFIX = "memory_v5_pending_tab:";
const ACTIVE_HANDOFF_PREFIX = "memory_v5_active_handoff:";
const AUTO_REQUEST_LIMIT_PER_UTC_DAY = 500;
const LOCAL_OUTBOX_MAX_ITEMS = 50;
const LOCAL_OUTBOX_MAX_BYTES = 20 * 1024;
const LOCAL_TURN_MAX_BYTES = 10 * 1024;
const LOCAL_EMERGENCY_RECENT_MAX_BYTES = 16 * 1024;
const LOCAL_EMERGENCY_MAX_BYTES = 64 * 1024;
const CONVERSATION_RE = /\/c\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\/|$)/i;
const V5_HANDOFF_RE = /\[memory-v5-handoff:([A-Za-z0-9_-]+)\]/;
const V5_LANE_RE = /\[memory-v5-lane:(lane_[A-Za-z0-9_-]+)\]/;
const V5_VERSION_RE = /\[memory-v5-version:(\d+)\]/;
const LEGACY_HANDOFF_RE = /\[memory-handoff:([A-Za-z0-9_-]+)\]/;
const LEGACY_LANE_RE = /\[memory-lane:(lane_[A-Za-z0-9_-]+)\]/;
const CONTROL_SYNC_RE = /\[memory-control:sync:([A-Za-z0-9_-]+)\]/;
const POWER_SYNC_PREFIX = "mcsync-power-";
const OFFSCREEN_PATH = "offscreen.html";
let offscreenCreating = null;
const tabRouteKeys = new Map();

function bytesToBase64Url(bytes) {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function randomUrlSafe(byteLength = 32) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return bytesToBase64Url(bytes);
}

async function sha256UrlSafe(text) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(text)
  );
  return bytesToBase64Url(new Uint8Array(digest));
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(values) {
  return new Promise((resolve) => chrome.storage.local.set(values, resolve));
}

function storageRemove(keys) {
  return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 15000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal,
    });
  } catch (error) {
    if (controller.signal.aborted) throw new Error("network_timeout");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function bindingKey(conversationId) {
  return BINDING_PREFIX + conversationId;
}

function localPendingKey(conversationId) {
  return OUTBOX_PREFIX + conversationId;
}

function saveBoundaryKey(conversationId) {
  return SAVE_BOUNDARY_PREFIX + conversationId;
}

function pendingTabKey(tabId) {
  return PENDING_TAB_PREFIX + tabId;
}

function activeHandoffKey(conversationId) {
  return ACTIVE_HANDOFF_PREFIX + conversationId;
}

async function activeHandoffGet(conversationId) {
  if (!conversationId) return null;
  const key = activeHandoffKey(conversationId);
  const values = await chrome.storage.session.get(key);
  const value = values[key];
  return value && typeof value === "object" ? value : null;
}

async function activeHandoffClear(conversationId) {
  if (!conversationId) return;
  await chrome.storage.session.remove(activeHandoffKey(conversationId));
}

async function activeHandoffSet(conversationId, value) {
  if (!conversationId || !value) return;
  await chrome.storage.session.set({
    [activeHandoffKey(conversationId)]: value,
  });
}

function conversationIdFromUrl(url) {
  return String(url || "").match(CONVERSATION_RE)?.[1] ?? null;
}

function routeKeyFromUrl(url) {
  try {
    const parsed = new URL(String(url || ""));
    const conversationId = conversationIdFromUrl(parsed.href);
    return conversationId
      ? "conversation:" + conversationId
      : "path:" + parsed.pathname;
  } catch {
    return String(url || "");
  }
}

function isTransientServiceError(value) {
  const text = String(value || "");
  return /service_quota_unavailable|service_unavailable|network_timeout|automatic_request_budget_exhausted|oauth_metadata_unavailable|authorization_server_metadata_unavailable|daily request limit|limit exceeded|error code\s*1027|http[_ -]?429|http[_ -]?5\d\d|failed to fetch/i.test(text);
}

function externalFailure(error) {
  const message = String(error?.message || error || "unknown_error");
  return {
    ok: false,
    error: message,
    degraded: isTransientServiceError(message),
  };
}

function utcDayKey(now = new Date()) {
  return now.toISOString().slice(0, 10);
}

function nextUtcMidnightMs(now = Date.now()) {
  const date = new Date(now);
  return Date.UTC(
    date.getUTCFullYear(),
    date.getUTCMonth(),
    date.getUTCDate() + 1,
  );
}

function utf8Bytes(text) {
  return new TextEncoder().encode(String(text || "")).byteLength;
}

function clipUtf8(text, maxBytes) {
  const value = String(text || "");
  if (utf8Bytes(value) <= maxBytes) return value;
  let low = 0;
  let high = value.length;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (utf8Bytes(value.slice(0, mid)) <= maxBytes) low = mid;
    else high = mid - 1;
  }
  return value.slice(0, low);
}

function containsHighConfidenceSecretText(value) {
  const text = String(value || "");
  return [
    /-----BEGIN(?: [A-Z0-9]+)? PRIVATE KEY-----/i,
    /\bsk-[A-Za-z0-9_-]{16,}\b/,
    /\bgh[pousr]_[A-Za-z0-9]{20,}\b/,
    /\bAKIA[0-9A-Z]{16}\b/,
    /\bAIza[0-9A-Za-z_-]{30,}\b/,
    /\bxox[baprs]-[A-Za-z0-9-]{16,}\b/,
    /\bBearer\s+[A-Za-z0-9._~+\/-]{20,}\b/i,
  ].some((pattern) => pattern.test(text));
}

async function localPendingGet(conversationId) {
  if (!conversationId) {
    return {
      items: [],
      overflowed: false,
      sensitiveOmitted: 0,
      sensitiveOmissions: [],
    };
  }
  const key = localPendingKey(conversationId);
  const values = await storageGet(key);
  const stored = values[key];
  if (!stored || typeof stored !== "object") {
    return {
      items: [],
      overflowed: false,
      sensitiveOmitted: 0,
      sensitiveOmissions: [],
    };
  }
  const sensitiveOmissions = Array.isArray(stored.sensitiveOmissions)
    ? stored.sensitiveOmissions
        .map((value) => Number(value))
        .filter(Number.isFinite)
        .slice(-LOCAL_OUTBOX_MAX_ITEMS)
    : [];
  return {
    items: Array.isArray(stored.items) ? stored.items : [],
    overflowed: Boolean(stored.overflowed),
    sensitiveOmitted: sensitiveOmissions.length,
    sensitiveOmissions,
  };
}

async function localPendingSet(conversationId, state) {
  const key = localPendingKey(conversationId);
  const items = Array.isArray(state?.items) ? state.items : [];
  const overflowed = Boolean(state?.overflowed);
  const sensitiveOmissions = Array.isArray(state?.sensitiveOmissions)
    ? state.sensitiveOmissions
        .map((value) => Number(value))
        .filter(Number.isFinite)
        .slice(-LOCAL_OUTBOX_MAX_ITEMS)
    : [];
  const sensitiveOmitted = sensitiveOmissions.length;
  if (!items.length && !overflowed && sensitiveOmitted === 0) {
    await storageRemove(key);
    return {
      items: [],
      overflowed: false,
      sensitiveOmitted: 0,
      sensitiveOmissions: [],
    };
  }
  const value = {
    items,
    overflowed,
    sensitiveOmitted,
    sensitiveOmissions,
    updatedAt: new Date().toISOString(),
  };
  await storageSet({ [key]: value });
  return value;
}

async function localPendingAdd(conversationId, item) {
  if (!conversationId) throw new Error("conversation_id_missing");
  const current = await localPendingGet(conversationId);
  const turnId = String(item?.turnId || "");
  const rawContent = String(item?.content || "").trim();
  if (!turnId || !rawContent) return current;
  if (containsHighConfidenceSecretText(rawContent)) {
    return localPendingSet(conversationId, {
      items: current.items,
      overflowed: true,
      sensitiveOmissions: [
        ...(Array.isArray(current.sensitiveOmissions)
          ? current.sensitiveOmissions
          : []),
        Number(item?.capturedAt || Date.now()),
      ],
    });
  }
  const content = clipUtf8(rawContent, LOCAL_TURN_MAX_BYTES);

  const nextItems = current.items.filter((entry) => entry.turnId !== turnId);
  nextItems.push({
    turnId,
    content,
    titleSeed: cleanTitleSeed(item?.titleSeed || ""),
    capturedAt: Number(item?.capturedAt || Date.now()),
  });

  let totalBytes = utf8Bytes(JSON.stringify(nextItems));
  let overflowed = current.overflowed;
  while (
    nextItems.length > LOCAL_OUTBOX_MAX_ITEMS ||
    totalBytes > LOCAL_OUTBOX_MAX_BYTES
  ) {
    nextItems.shift();
    overflowed = true;
    totalBytes = utf8Bytes(JSON.stringify(nextItems));
  }

  return localPendingSet(conversationId, {
    items: nextItems,
    overflowed,
    sensitiveOmissions: current.sensitiveOmissions,
  });
}

async function localPendingClearThrough(conversationId, boundaryAt) {
  if (!conversationId || !Number.isFinite(boundaryAt)) return;
  const current = await localPendingGet(conversationId);
  const remaining = current.items.filter(
    (item) => Number(item.capturedAt || 0) > boundaryAt
  );
  const remainingSensitiveOmissions = (
    Array.isArray(current.sensitiveOmissions)
      ? current.sensitiveOmissions
      : []
  ).filter((capturedAt) => Number(capturedAt) > boundaryAt);
  await localPendingSet(conversationId, {
    items: remaining,
    overflowed:
      remaining.length > 0 || remainingSensitiveOmissions.length > 0
        ? current.overflowed
        : false,
    sensitiveOmissions: remainingSensitiveOmissions,
  });
}

async function saveBoundarySet(conversationId, syncKey) {
  const existing = await saveBoundaryGet(conversationId, syncKey);
  if (existing) return existing;

  const value = {
    syncKey: String(syncKey || ""),
    capturedAt: Date.now(),
    attempts: 0,
    status: "pending",
    registered: false,
  };
  await storageSet({ [saveBoundaryKey(conversationId)]: value });
  return value;
}

async function saveBoundaryCurrent(conversationId) {
  if (!conversationId) return null;
  const key = saveBoundaryKey(conversationId);
  const value = (await storageGet(key))[key];
  return value && typeof value === "object" ? value : null;
}

async function saveBoundaryGet(conversationId, syncKey) {
  const value = await saveBoundaryCurrent(conversationId);
  if (!value || String(value.syncKey || "") !== String(syncKey || "")) {
    return null;
  }
  return value;
}

async function saveBoundaryUpdate(conversationId, syncKey, updates = {}) {
  const boundary = await saveBoundaryGet(conversationId, syncKey);
  if (!boundary) return null;
  const value = { ...boundary, ...updates };
  await storageSet({ [saveBoundaryKey(conversationId)]: value });
  return value;
}

async function saveBoundaryClear(conversationId, syncKey) {
  const boundary = await saveBoundaryGet(conversationId, syncKey);
  if (!boundary) return;
  await storageRemove(saveBoundaryKey(conversationId));
}

function pendingForHandoff(localState, pageState) {
  const localItems = Array.isArray(localState?.items) ? localState.items : [];
  const pageItems = Array.isArray(pageState?.items) ? pageState.items : [];

  const pageIds = new Set(
    pageItems
      .map((item) => String(item?.turnId || item?.turn_id || "").trim())
      .filter(Boolean)
  );
  const pageContentCounts = new Map();
  for (const item of pageItems) {
    const content = String(item?.content || "").trim();
    if (!content) continue;
    pageContentCounts.set(content, (pageContentCounts.get(content) || 0) + 1);
  }

  const localOnly = [];
  for (const item of localItems) {
    const turnId = String(item?.turnId || item?.turn_id || "").trim();
    const content = String(item?.content || "").trim();
    if (turnId && pageIds.has(turnId)) continue;
    const pageCount = pageContentCounts.get(content) || 0;
    if (content && pageCount > 0) {
      pageContentCounts.set(content, pageCount - 1);
      continue;
    }
    localOnly.push(item);
  }

  // DOM page order is authoritative for the visible/latest suffix.
  // Local-only items are prepended as older recovery evidence.
  const sources = [...localOnly, ...pageItems];
  const ordered = [];
  const seen = new Set();
  let bytes = 0;
  let overflowed = Boolean(localState?.overflowed || pageState?.overflowed);
  let sensitiveOmitted =
    Number(
      Array.isArray(localState?.sensitiveOmissions)
        ? localState.sensitiveOmissions.length
        : localState?.sensitiveOmitted || 0
    ) +
    Number(pageState?.sensitiveOmitted || 0);

  for (const raw of sources) {
    const turnId = String(raw?.turnId || raw?.turn_id || "").trim();
    if (!turnId || seen.has(turnId)) continue;
    const rawContent = String(raw?.content || "").trim();
    if (!rawContent) continue;
    if (containsHighConfidenceSecretText(rawContent)) {
      sensitiveOmitted += 1;
      overflowed = true;
      continue;
    }
    const content = clipUtf8(rawContent, LOCAL_TURN_MAX_BYTES);
    const capturedAt = Number(raw?.capturedAt);
    const item = {
      turnId: turnId.slice(0, 200),
      content,
      capturedAt: Number.isFinite(capturedAt) ? capturedAt : null,
    };
    const itemBytes = utf8Bytes(JSON.stringify(item));
    if (
      ordered.length >= LOCAL_OUTBOX_MAX_ITEMS ||
      bytes + itemBytes > LOCAL_OUTBOX_MAX_BYTES
    ) {
      overflowed = true;
      break;
    }
    bytes += itemBytes;
    seen.add(turnId);
    ordered.push(item);
  }
  return { items: ordered, overflowed, sensitive_omitted: sensitiveOmitted };
}

async function backendHealthGet() {
  const value = (await storageGet(BACKEND_HEALTH_KEY))[BACKEND_HEALTH_KEY];
  return value && typeof value === "object" ? value : null;
}

async function backendHealthBlock(reason) {
  const now = Date.now();
  const quota = String(reason || "") === "service_quota_unavailable";
  const value = {
    reason: String(reason || "service_unavailable"),
    blockedUntil: quota ? nextUtcMidnightMs(now) : now + 60_000,
    updatedAt: now,
  };
  await storageSet({ [BACKEND_HEALTH_KEY]: value });
  return value;
}

async function backendHealthClear() {
  await storageRemove(BACKEND_HEALTH_KEY);
}

async function assertBackendAvailable() {
  const health = await backendHealthGet();
  if (!health) return;
  if (Number(health.blockedUntil || 0) <= Date.now()) {
    await backendHealthClear();
    return;
  }
  throw new Error(String(health.reason || "service_unavailable"));
}

async function backendFetch(url, options = {}) {
  try {
    return await fetchWithTimeout(url, options);
  } catch (error) {
    const message = String(error?.message || error || "network_timeout");
    if (isTransientServiceError(message)) {
      await backendHealthBlock("service_unavailable");
    }
    throw error;
  }
}

async function consumeAutomaticRequestBudget() {
  const day = utcDayKey();
  const current = (await storageGet(AUTO_BUDGET_KEY))[AUTO_BUDGET_KEY];
  const count = current?.day === day ? Number(current.count || 0) : 0;
  if (count >= AUTO_REQUEST_LIMIT_PER_UTC_DAY) {
    throw new Error("automatic_request_budget_exhausted");
  }
  await storageSet({
    [AUTO_BUDGET_KEY]: {
      day,
      count: count + 1,
      updatedAt: Date.now(),
    },
  });
}

async function pendingTabGet(tabId) {
  const key = pendingTabKey(tabId);
  const values = await chrome.storage.session.get(key);
  return Array.isArray(values[key]) ? values[key] : [];
}

async function pendingTabSet(tabId, items) {
  const key = pendingTabKey(tabId);
  if (!items.length) {
    await chrome.storage.session.remove(key);
    return;
  }
  await chrome.storage.session.set({ [key]: items.slice(-20) });
}

async function enqueuePendingTab(tabId, item) {
  if (!Number.isInteger(tabId)) throw new Error("tab_id_missing");
  const items = await pendingTabGet(tabId);
  const dedupeKey = item.kind === "bind"
    ? "bind:" + (item.token || item.laneId)
    : "turn:" + item.turnId;
  const filtered = items.filter((existing) => {
    const existingKey = existing.kind === "bind"
      ? "bind:" + (existing.token || existing.laneId)
      : "turn:" + existing.turnId;
    return existingKey !== dedupeKey;
  });
  filtered.push({ ...item, queuedAt: Date.now() });
  await pendingTabSet(tabId, filtered);
  return filtered.length;
}

async function injectCurrentArchitecture(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    files: ["page_agent.js"],
  });
}

async function storeSendBoundaryInTab(
  tabId,
  { conversationId = null, userText = "", turnId = "" } = {}
) {
  if (!Number.isInteger(tabId)) return false;
  const text = String(userText || "").trim();
  if (!text) return false;

  const result = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: ({ conversationId, userText, turnId }) => {
      const key = "memory_v5_assistant_boundary_v1";
      const prompt =
        document.querySelector("#prompt-textarea") ||
        document.querySelector('[data-testid="composer-text-input"]') ||
        document.querySelector("form textarea") ||
        document.querySelector('[contenteditable="true"][role="textbox"]') ||
        document.querySelector('div[contenteditable="true"]');
      const surface =
        document.querySelector("main") ||
        document.querySelector('[role="main"]') ||
        prompt?.closest?.('main,[role="main"]') ||
        document.body ||
        null;
      const value = surface
        ? (surface.innerText || surface.textContent || "").trim()
        : "";
      const beforeTail = value.slice(Math.max(0, value.length - 12000)).trim();
      const record = {
        conversation_id: conversationId || null,
        turn_id: String(turnId || ""),
        user_text: String(userText || "").trim().slice(0, 8000),
        before_tail: beforeTail,
        captured_at: Date.now(),
        source: "background_send_repair",
      };
      try {
        sessionStorage.setItem(key, JSON.stringify(record));
        return true;
      } catch {
        return false;
      }
    },
    args: [{ conversationId, userText: text, turnId }],
  }).catch(() => []);

  return Boolean(result?.[0]?.result);
}

async function rehydrateOpenChatgptTabs(reason = "extension_reload") {
  const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*"] });
  const results = [];

  for (const tab of tabs) {
    if (!Number.isInteger(tab.id)) continue;
    const tabId = tab.id;
    try {
      await injectCurrentArchitecture(tabId);
      if (tab.url) tabRouteKeys.set(tabId, routeKeyFromUrl(tab.url));
      results.push({ tabId, ok: true, reinjected: true });
    } catch (error) {
      results.push({
        tabId,
        ok: false,
        error: String(error?.message || error),
      });
    }
  }

  await storageSet({
    memory_v5_power_last_rehydrate: {
      reason,
      at: new Date().toISOString(),
      results,
    },
  });
  return results;
}

function canonicalReadySource(value) {
  return (
    value === "checkpoint_sync" ||
    value === "canonical_handoff" ||
    value === "remote_binding"
  );
}

async function getBinding(conversationId) {
  if (!conversationId) return null;
  const key = bindingKey(conversationId);
  const values = await storageGet(key);
  const stored = values[key] ?? null;
  if (!stored || typeof stored !== "object") return null;

  const legacyCheckpointProof =
    Number.isInteger(stored.savedVersion) &&
    stored.savedVersion >= 2 &&
    typeof stored.lastSyncKey === "string" &&
    stored.lastSyncKey.length > 0;
  const readinessSource =
    typeof stored.readinessSource === "string"
      ? stored.readinessSource
      : legacyCheckpointProof
        ? "checkpoint_sync"
        : "";
  const ready =
    Boolean(stored.ready) && canonicalReadySource(readinessSource);

  if (
    stored.ready !== ready ||
    stored.readinessSource !== readinessSource
  ) {
    const migrated = {
      ...stored,
      ready,
      readinessSource,
      updatedAt: new Date().toISOString(),
    };
    await storageSet({ [key]: migrated });
    return migrated;
  }
  return stored;
}

async function clearBinding(conversationId) {
  if (!conversationId) return;
  await storageRemove(bindingKey(conversationId));
}

async function setBinding(
  conversationId,
  laneId,
  titleSeed = "",
  {
    ready = undefined,
    savedVersion = undefined,
    lastSyncKey = undefined,
    readinessSource = undefined,
    lifecycleState = undefined,
    resumeConfirmationRequired = undefined,
  } = {}
) {
  if (!conversationId || !laneId) throw new Error("binding_missing_identity");
  const key = bindingKey(conversationId);
  const prior = await getBinding(conversationId);
  const sameLane = prior?.laneId === laneId;
  const nextReadinessSource =
    readinessSource !== undefined
      ? String(readinessSource || "")
      : sameLane
        ? String(prior?.readinessSource || "")
        : "";
  const nextReady =
    ready === undefined
      ? Boolean(sameLane && prior?.ready)
      : Boolean(ready);
  if (nextReady && !canonicalReadySource(nextReadinessSource)) {
    throw new Error("binding_ready_proof_required");
  }

  const value = {
    laneId,
    titleSeed:
      typeof titleSeed === "string" && titleSeed
        ? titleSeed
        : sameLane
          ? String(prior?.titleSeed || "")
          : "",
    ready: nextReady,
    readinessSource: nextReadinessSource,
    savedVersion:
      savedVersion !== undefined
        ? Number.isInteger(savedVersion)
          ? savedVersion
          : null
        : sameLane && Number.isInteger(prior?.savedVersion)
          ? prior.savedVersion
          : null,
    lastSyncKey:
      lastSyncKey !== undefined
        ? String(lastSyncKey || "")
        : sameLane
          ? String(prior?.lastSyncKey || "")
          : "",
    lifecycleState:
      lifecycleState !== undefined
        ? String(lifecycleState || "")
        : sameLane
          ? String(prior?.lifecycleState || "")
          : "",
    resumeConfirmationRequired:
      resumeConfirmationRequired !== undefined
        ? Boolean(resumeConfirmationRequired)
        : Boolean(sameLane && prior?.resumeConfirmationRequired),
    updatedAt: new Date().toISOString(),
  };
  await storageSet({ [key]: value });
  return value;
}

async function oauthMetadata() {
  const issuer = String(CONFIG.authIssuer || "").replace(/\/$/, "");
  if (!issuer) throw new Error("oauth_issuer_not_configured");
  return {
    issuer,
    authorization_endpoint: issuer + "/oauth2/authorize",
    token_endpoint: issuer + "/oauth2/token",
  };
}

async function storeTokens(payload) {
  if (!payload?.access_token) throw new Error("oauth_token_missing");
  const prior = (await storageGet(AUTH_KEY))[AUTH_KEY] ?? {};
  const expiresIn = Number(payload.expires_in ?? 3600);
  const auth = {
    accessToken: payload.access_token,
    refreshToken: payload.refresh_token ?? prior.refreshToken ?? null,
    expiresAt: Date.now() + Math.max(60, expiresIn) * 1000,
    scope: payload.scope ?? prior.scope ?? null,
    tokenType: payload.token_type ?? "Bearer",
  };
  await storageSet({ [AUTH_KEY]: auth });
  return auth;
}

async function refreshAuth() {
  const stored = (await storageGet(AUTH_KEY))[AUTH_KEY];
  if (!stored?.refreshToken) throw new Error("auth_required");
  if (!CONFIG.oauthClientId) throw new Error("oauth_client_not_configured");

  const metadata = await oauthMetadata();
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: CONFIG.oauthClientId,
    refresh_token: stored.refreshToken,
    resource: CONFIG.resource,
  });

  const response = await fetchWithTimeout(metadata.token_endpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!response.ok) {
    await storageRemove(AUTH_KEY);
    throw new Error("auth_required");
  }
  return storeTokens(await response.json());
}

async function accessToken() {
  const stored = (await storageGet(AUTH_KEY))[AUTH_KEY];
  if (!stored?.accessToken) throw new Error("auth_required");
  if (Number(stored.expiresAt ?? 0) > Date.now() + 60_000) {
    return stored.accessToken;
  }
  const refreshed = await refreshAuth();
  return refreshed.accessToken;
}

async function login() {
  if (!CONFIG.oauthClientId) throw new Error("oauth_client_not_configured");

  const metadata = await oauthMetadata();
  const redirectUri = chrome.identity.getRedirectURL("memory-v5");
  const verifier = randomUrlSafe(48);
  const challenge = await sha256UrlSafe(verifier);
  const state = randomUrlSafe(24);

  const authorize = new URL(metadata.authorization_endpoint);
  authorize.searchParams.set("client_id", CONFIG.oauthClientId);
  authorize.searchParams.set("redirect_uri", redirectUri);
  authorize.searchParams.set("response_type", "code");
  authorize.searchParams.set("scope", CONFIG.scopes.join(" "));
  authorize.searchParams.set("code_challenge", challenge);
  authorize.searchParams.set("code_challenge_method", "S256");
  authorize.searchParams.set("state", state);
  authorize.searchParams.set("resource", CONFIG.resource);

  const redirected = await chrome.identity.launchWebAuthFlow({
    url: authorize.href,
    interactive: true,
  });
  if (!redirected) throw new Error("oauth_redirect_missing");

  const callback = new URL(redirected);
  if (callback.searchParams.get("state") !== state) {
    throw new Error("oauth_state_mismatch");
  }
  const callbackError = callback.searchParams.get("error");
  if (callbackError) throw new Error("oauth_" + callbackError);

  const code = callback.searchParams.get("code");
  if (!code) throw new Error("oauth_code_missing");

  const body = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: CONFIG.oauthClientId,
    code,
    code_verifier: verifier,
    redirect_uri: redirectUri,
    resource: CONFIG.resource,
  });

  const response = await fetchWithTimeout(metadata.token_endpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!response.ok) throw new Error("oauth_token_exchange_failed");
  const auth = await storeTokens(await response.json());
  return {
    authenticated: true,
    expiresAt: auth.expiresAt,
    redirectUri,
  };
}

async function companionFetch(path, payload, token) {
  try {
    return await backendFetch(CONFIG.apiBase.replace(/\/$/, "") + path, {
      method: "POST",
      headers: {
        authorization: "Bearer " + token,
        "content-type": "application/json",
      },
      body: JSON.stringify(payload),
    });
  } catch (error) {
    if (isTransientServiceError(error?.message || error)) {
      await backendHealthBlock("service_unavailable");
    }
    throw error;
  }
}

async function companionPost(path, payload, options = {}) {
  await assertBackendAvailable();
  if (options.automatic) await consumeAutomaticRequestBudget();
  let token = await accessToken();
  let response = await companionFetch(path, payload, token);

  if (response.status === 401) {
    const refreshed = await refreshAuth();
    token = refreshed.accessToken;
    response = await companionFetch(path, payload, token);
  }

  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = null;
  }

  if (!response.ok) {
    if (
      response.status === 429 ||
      /daily request limit|limit exceeded|error code\s*1027/i.test(text)
    ) {
      await backendHealthBlock("service_quota_unavailable");
      throw new Error("service_quota_unavailable");
    }
    if (response.status >= 500) {
      await backendHealthBlock("service_unavailable");
      throw new Error("service_unavailable");
    }
    throw new Error(data?.error || ("companion_http_" + response.status));
  }
  if (!data || typeof data !== "object") throw new Error("invalid_json");
  await backendHealthClear();
  return data;
}

async function bindConversationFromHandoffProof({
  conversationId,
  token,
  laneId,
  savedVersion,
  titleSeed = "",
}) {
  if (!conversationId) throw new Error("conversation_id_missing");
  if (!token || !laneId || !Number.isSafeInteger(savedVersion)) {
    throw new Error("handoff_binding_proof_incomplete");
  }

  const result = await companionPost(
    "/companion/binding/from-handoff",
    {
      source_conversation_id: conversationId,
      token,
      lane_id: laneId,
      snapshot_version: savedVersion,
    }
  );
  if (
    result?.status !== "ok" ||
    result?.lane_id !== laneId ||
    Number(result?.snapshot_version) !== savedVersion ||
    result?.binding?.lane_id !== laneId
  ) {
    throw new Error("handoff_binding_proof_mismatch");
  }

  return setBinding(
    conversationId,
    laneId,
    titleSeed,
    {
      ready: Boolean(result.ready),
      savedVersion,
      lastSyncKey: "",
      readinessSource: "remote_binding",
      lifecycleState: String(result.lifecycle_state || ""),
      resumeConfirmationRequired: Boolean(
        result.resume_confirmation_required ?? true
      ),
    }
  );
}

async function flushPendingTab(tabId, conversationId) {
  const items = await pendingTabGet(tabId);
  if (!items.length) return { flushed: 0 };

  const remaining = [];
  let flushed = 0;
  for (let index = 0; index < items.length; index += 1) {
    const item = items[index];
    try {
      if (item.kind === "bind") {
        if (
          item.token &&
          item.laneId &&
          Number.isSafeInteger(item.savedVersion)
        ) {
          await bindConversationFromHandoffProof({
            conversationId,
            token: item.token,
            laneId: item.laneId,
            savedVersion: item.savedVersion,
            titleSeed: item.titleSeed || "",
          });
        } else {
          await setBinding(
            conversationId,
            item.laneId,
            item.titleSeed || "",
            {
              ready: Boolean(item.ready),
              savedVersion: Number.isSafeInteger(item.savedVersion)
                ? item.savedVersion
                : null,
              lastSyncKey: "",
              readinessSource: String(item.readinessSource || ""),
            }
          );
        }
      } else if (item.kind === "turn") {
        await localPendingAdd(conversationId, item);
      }
      flushed += 1;
    } catch {
      remaining.push(item, ...items.slice(index + 1));
      break;
    }
  }

  await pendingTabSet(tabId, remaining);
  return { flushed, remaining: remaining.length };
}

async function handleTabUrlChange(
  tabId,
  url,
  { injectOnRouteChange = false } = {}
) {
  if (!Number.isInteger(tabId) || !String(url || "").startsWith("https://chatgpt.com/")) {
    return;
  }

  const conversationId = conversationIdFromUrl(url);
  if (conversationId) {
    await flushPendingTab(tabId, conversationId);
  }

  if (!injectOnRouteChange) return;

  const nextRouteKey = routeKeyFromUrl(url);
  const priorRouteKey = tabRouteKeys.get(tabId) || null;
  if (priorRouteKey === nextRouteKey) return;

  tabRouteKeys.set(tabId, nextRouteKey);
  await injectCurrentArchitecture(tabId).catch(() => {});
}

async function authStatus() {
  const auth = (await storageGet(AUTH_KEY))[AUTH_KEY] ?? null;
  return {
    configured: Boolean(CONFIG.oauthClientId),
    authenticated: Boolean(auth?.accessToken || auth?.refreshToken),
    expiresAt: auth?.expiresAt ?? null,
    redirectUri: chrome.identity.getRedirectURL("memory-v5"),
    apiBase: CONFIG.apiBase,
  };
}

function looksLikeLocalEmergencyPackage(value) {
  const text = String(value || "");
  if (!/\[memory-v5-local-emergency\]/.test(text)) return false;
  return (
    /\[memory-v5-emergency-id:[^\]]+\]/.test(text) ||
    /@EmergencyId\s+\S+/.test(text) ||
    /【本地未同步用户请求】/.test(text) ||
    /这是本地(?:应急续聊|续聊恢复)包/.test(text)
  );
}

function handoffMarkers(text) {
  const value = String(text || "");
  const v5Token = value.match(V5_HANDOFF_RE)?.[1] ?? null;
  const v5LaneId = value.match(V5_LANE_RE)?.[1] ?? null;
  const v5VersionRaw = value.match(V5_VERSION_RE)?.[1] ?? null;
  const v5Version =
    v5VersionRaw != null && Number.isSafeInteger(Number(v5VersionRaw))
      ? Number(v5VersionRaw)
      : null;
  const localEmergency = looksLikeLocalEmergencyPackage(value);
  if (localEmergency) {
    return {
      token: null,
      laneId: v5LaneId,
      savedVersion: v5Version,
      kind: v5LaneId ? "local_emergency" : "local_emergency_unbound",
    };
  }
  if (v5Token || v5LaneId) {
    const explicitContinuation =
      /(?:只)?使用已连接的\s*Memory V5 Beta/i.test(value) &&
      /(?:精确恢复(?:并锁定)?原任务线|精确恢复此任务)/.test(value);
    return {
      token: v5Token,
      laneId: v5LaneId,
      savedVersion: v5Version,
      kind:
        v5Token &&
        v5LaneId &&
        Number.isSafeInteger(v5Version) &&
        explicitContinuation
          ? "v5"
          : v5Token && v5LaneId && !explicitContinuation
            ? "quoted_v5"
            : "malformed_v5",
    };
  }

  const legacyToken = value.match(LEGACY_HANDOFF_RE)?.[1] ?? null;
  const legacyLaneId = value.match(LEGACY_LANE_RE)?.[1] ?? null;
  if (legacyToken || legacyLaneId) {
    return {
      token: legacyToken,
      laneId: legacyLaneId,
      kind:
        legacyToken && legacyLaneId
          ? "legacy_v5"
          : legacyToken
            ? "v4"
            : "malformed_legacy",
    };
  }
  return { token: null, laneId: null, savedVersion: null, kind: "none" };
}

function cleanTitleSeed(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

function isControlLikeSeed(value) {
  const text = String(value || "").trim();
  if (!text) return true;
  return /(?:memory-(?:v5-)?handoff|memory-(?:v5-)?lane|memory-control|devspace plain|先恢复并校准任务|恢复原对话上下文|确认任务目的.{0,20}当前主线|使用已连接的 memory v5|待校准：power 自动建 lane|正式任务目的尚未)/i.test(text);
}

function conciseSeedPart(value, max = 42) {
  const text = cleanTitleSeed(value)
    .replace(/^[\s#>*\-–—:：]+/, "")
    .replace(/[。；;，,]+$/g, "")
    .trim();
  if (!text || isControlLikeSeed(text)) return "";
  return text.slice(0, max);
}

function handoffTitleSeed(result, context = {}) {
  const page = conciseSeedPart(context.titleSeed, 36);
  const task = conciseSeedPart(result.task_title, 36);
  const next = conciseSeedPart(result.working_next_action, 40);
  const goal = conciseSeedPart(result.task_goal, 40);
  const primary = page || task || next || goal;
  if (
    primary &&
    next &&
    primary !== next &&
    !primary.includes(next) &&
    !next.includes(primary)
  ) {
    return (primary + "｜" + next).slice(0, 80);
  }
  return (primary || "Memory V5").slice(0, 80);
}

function continuationText(result, context = {}) {
  const seed = handoffTitleSeed(result, context);
  return [
    seed,
    "",
    "[memory-v5-handoff:" + result.token + "]",
    "[memory-v5-lane:" + result.lane_id + "]",
    Number.isInteger(result.snapshot_version)
      ? "[memory-v5-version:" + result.snapshot_version + "]"
      : "",
    "",
    "使用已连接的 Memory V5 Beta 精确恢复此任务；禁止按标题/语义猜线、并线。",
    "回复必须简洁，且先只汇报，不执行：",
    "1. 首句：任务名｜当前主线。优先沿用最上面的生产对话标题；不要写“恢复/校准/Memory/Handoff”等流程词。",
    "2. 目的：一句。",
    "3. 已完成：只列影响当前判断的结论。",
    "4. 已否决：只列仍影响后续选择的明确否决，合并同类项，用短语，不解释原因。",
    "5. 未解决：最后未完成节点。",
    "6. 下一步：唯一优先事项。",
    "有 pending user / assistant_tail 时，另加“未确认尾部”；assistant_tail 只能作未确认上下文。",
    "等用户确认后再继续。",
  ].filter(Boolean).join("\n");
}

function normalizedEmergencyContent(value) {
  return String(value || "")
    .replace(/^\s*(?:纯文本|复制代码|Copy code|已分析|Analyzed)\s*$/gim, "")
    .replace(/\s+/g, " ")
    .trim();
}

function emergencyDedupCanonical(value) {
  return normalizedEmergencyContent(value)
    .replace(/(?:\s|\u00a0)*(?:\.\.\.|…)+\s*$/u, "")
    .trim();
}

function emergencyContentEquivalent(a, b) {
  const left = emergencyDedupCanonical(a);
  const right = emergencyDedupCanonical(b);
  return Boolean(left && right && left === right);
}

function compactEmbeddedEmergencyUserContent(
  value,
  maxBytes = 10 * 1024,
  depth = 0
) {
  const text = String(value || "").trim();
  if (containsHighConfidenceSecretText(text)) {
    return "（检测到高置信敏感内容，用户消息正文已省略）";
  }
  if (!looksLikeLocalEmergencyPackage(text)) {
    return clipUtf8(text, maxBytes);
  }
  if (depth >= 1) {
    return "[nested-memory-v5-local-emergency omitted]\n说明：更深层嵌套应急包已省略，避免递归膨胀。";
  }

  const markerIndex = text.indexOf("[memory-v5-local-emergency]");
  const prefix = text.slice(0, markerIndex).trim();
  const emergencyId =
    text.match(/\[memory-v5-emergency-id:([^\]]+)\]/)?.[1] || "unknown";
  const emergencyFingerprint =
    text.match(/\[memory-v5-emergency-fingerprint:([^\]]+)\]/)?.[1] ||
    "unknown";
  const sourceChat =
    text.match(/\[memory-v5-source-chat:([^\]]+)\]/)?.[1] || "unknown";
  const laneId =
    text.match(/\[memory-v5-lane:([^\]]+)\]/)?.[1] || "unknown";
  const version =
    text.match(/\[memory-v5-version:([^\]]+)\]/)?.[1] || "unknown";

  const pendingSection =
    text.match(
      /【本地未同步用户请求】([\s\S]*?)(?=【最近关键聊天|\n要求：|$)/
    )?.[1] || "";
  const pendingBlocks = pendingSection
    .split(/(?=\[pending-user-\d+\])/)
    .map((item) => item.trim())
    .filter((item) => /^\[pending-user-\d+\]/.test(item))
    .slice(-3)
    .map((block) => {
      const lines = block.split("\n");
      const header = [];
      const body = [];
      let inBody = false;
      for (const line of lines) {
        if (!inBody && /^\s*(?:\[pending-user-|@id |@user-evidence )/.test(line)) {
          header.push(line);
          continue;
        }
        inBody = true;
        body.push(line);
      }
      return [
        ...header,
        compactEmbeddedEmergencyUserContent(
          body.join("\n").trim(),
          2 * 1024,
          depth + 1
        ),
      ].filter(Boolean).join("\n");
    });

  return clipUtf8(
    [
      prefix,
      "[embedded-memory-v5-local-emergency compacted]",
      "@embedded-emergency-id " + emergencyId,
      "@embedded-fingerprint " + emergencyFingerprint,
      "@embedded-source-chat " + sourceChat,
      "@embedded-lane " + laneId,
      "@embedded-version " + version,
      "",
      "【嵌套应急包最近用户请求】",
      pendingBlocks.length
        ? pendingBlocks.join("\n\n")
        : "（嵌套应急包未解析到 pending user）",
      "",
      "说明：嵌套应急包中的 Assistant / recent context 已省略，避免 Emergency 递归膨胀；这些被省略内容本来就只属于未确认上下文。",
    ]
      .filter(Boolean)
      .join("\n"),
    maxBytes
  );
}

function emergencyPendingView(pending, hasCanonicalBaseline) {
  const items = Array.isArray(pending?.items) ? pending.items : [];
  if (hasCanonicalBaseline) {
    return {
      items,
      scope: "post_checkpoint_delta",
      omitted_before: 0,
    };
  }
  const selected = items.slice(-3);
  return {
    items: selected,
    scope: "recent_unanchored_tail",
    omitted_before: Math.max(0, items.length - selected.length),
  };
}

function emergencyRecentContextText(
  recentContext,
  pending,
  assistantTail,
  maxBytes = LOCAL_EMERGENCY_RECENT_MAX_BYTES
) {
  const rounds = Array.isArray(recentContext?.rounds)
    ? recentContext.rounds.slice(-3)
    : [];
  const captureQuality = String(
    recentContext?.capture_quality || "unavailable"
  );
  const degradedEvidence = captureQuality === "degraded_surface";
  const pendingItems = Array.isArray(pending?.items) ? pending.items : [];
  const pendingIds = new Set(
    pendingItems.map((item) => String(item?.turnId || "")).filter(Boolean)
  );
  const pendingContents = new Set(
    pendingItems
      .map((item) => normalizedEmergencyContent(item?.content))
      .filter(Boolean)
  );

  const selected = [];
  const budgetBytes = Math.max(
    0,
    Math.min(LOCAL_EMERGENCY_RECENT_MAX_BYTES, Number(maxBytes || 0))
  );
  let remaining = budgetBytes;
  let sensitiveOmitted = 0;
  let overflowed = Boolean(recentContext?.overflowed);

  const renderTurnContent = (raw, maxBytes) => {
    const text = String(raw || "").trim();
    if (!text) return "（空）";
    if (containsHighConfidenceSecretText(text)) {
      sensitiveOmitted += 1;
      return "（检测到高置信敏感内容，正文已省略）";
    }
    return clipUtf8(text, maxBytes);
  };

  const renderRound = (round, ordinal) => {
    const user = round?.user || {};
    const assistant = round?.assistant || {};
    const userId = String(user.turnId || "unknown");
    const assistantId = String(assistant.turnId || "unknown");
    const normalizedUser = normalizedEmergencyContent(user.content);
    const duplicatePending =
      pendingIds.has(userId) ||
      (normalizedUser && pendingContents.has(normalizedUser)) ||
      pendingItems.some((item) =>
        emergencyContentEquivalent(item?.content, user.content)
      );
    const userText = duplicatePending
      ? "（同一用户请求已在【本地未同步用户请求】中完整保留）"
      : compactEmbeddedEmergencyUserContent(user.content, 6 * 1024);
    const assistantText = renderTurnContent(assistant.content, 9 * 1024);
    const roundCompleteness =
      user?.truncated || assistant?.truncated
        ? "false"
        : user?.completeness === "unknown" ||
            assistant?.completeness === "unknown"
          ? "unknown"
          : "true";
    const userEvidence = degradedEvidence
      ? "surface_parsed_unverified"
      : "user_message";
    const assistantEvidence = degradedEvidence
      ? "surface_parsed_unverified"
      : "unconfirmed_context";
    return [
      "[recent-round-" + ordinal + "]",
      "@round_complete " + roundCompleteness,
      roundCompleteness === "false"
        ? "@round_incomplete_reason turn_content_limit"
        : "",
      "@user-id " + userId,
      "@user-evidence " + userEvidence,
      user?.truncated ? "@user_truncated true" : "",
      userText,
      "",
      "@assistant-id " + assistantId,
      "@assistant-evidence " + assistantEvidence,
      assistant?.truncated ? "@assistant_truncated true" : "",
      assistantText,
    ].filter(Boolean).join("\n");
  };

  for (let index = rounds.length - 1; index >= 0; index -= 1) {
    const ordinal = index + 1;
    const sensitiveBefore = sensitiveOmitted;
    let block = renderRound(rounds[index], ordinal);
    const separatorBytes = selected.length ? utf8Bytes("\n\n") : 0;
    const blockBytes = utf8Bytes(block);
    if (blockBytes + separatorBytes <= remaining) {
      selected.unshift(block);
      remaining -= blockBytes + separatorBytes;
      continue;
    }
    if (selected.length === 0 && remaining > 512) {
      sensitiveOmitted = sensitiveBefore;
      const round = rounds[index] || {};
      const user = round.user || {};
      const assistant = round.assistant || {};
      const userId = String(user.turnId || "unknown");
      const assistantId = String(assistant.turnId || "unknown");
      const normalizedUser = normalizedEmergencyContent(user.content);
      const duplicatePending =
        pendingIds.has(userId) ||
        (normalizedUser && pendingContents.has(normalizedUser)) ||
        pendingItems.some((item) =>
          emergencyContentEquivalent(item?.content, user.content)
        );
      const userText = duplicatePending
        ? "（同一用户请求已在【本地未同步用户请求】中完整保留）"
        : compactEmbeddedEmergencyUserContent(user.content, 4 * 1024);
      const fixed = [
        "[recent-round-" + ordinal + "-excerpt]",
        "@round_complete false",
        "@reason recent_context_budget",
        "@user-id " + userId,
        "@user-evidence " + (degradedEvidence
          ? "surface_parsed_unverified"
          : "user_message"),
        userText,
        "",
        "@assistant-id " + assistantId,
        "@assistant-evidence " + (degradedEvidence
          ? "surface_parsed_unverified"
          : "unconfirmed_context"),
      ].join("\n") + "\n";
      const assistantBudget = Math.max(256, remaining - utf8Bytes(fixed));
      const assistantText = renderTurnContent(
        assistant.content,
        assistantBudget
      );
      block = fixed + assistantText;
      selected.unshift(clipUtf8(block, remaining));
      remaining = 0;
      overflowed = true;
    } else {
      overflowed = true;
    }
    break;
  }

  const rawTail =
    assistantTail && typeof assistantTail === "object" && assistantTail.content
      ? String(assistantTail.content)
      : "";
  const tailInRounds = rounds.some((round) => {
    const assistantText = normalizedEmergencyContent(round?.assistant?.content);
    const tailText = normalizedEmergencyContent(rawTail);
    return Boolean(
      assistantText &&
      tailText &&
      (assistantText === tailText ||
        assistantText.includes(tailText) ||
        tailText.includes(assistantText))
    );
  });
  if (
    rawTail &&
    !tailInRounds &&
    assistantTail?.generation_in_progress &&
    remaining > 512
  ) {
    const safeTail = containsHighConfidenceSecretText(rawTail)
      ? "（检测到高置信敏感内容，当前 Assistant 尾部已省略）"
      : clipUtf8(rawTail, Math.min(4 * 1024, remaining - 128));
    if (containsHighConfidenceSecretText(rawTail)) sensitiveOmitted += 1;
    const tailBlock = [
      "[current-assistant-tail]",
      "@round_complete false",
      "@reason generation_in_progress",
      "@assistant-evidence unconfirmed_context",
      "@status generation_in_progress",
      safeTail,
    ].join("\n");
    const tailSeparatorBytes = selected.length ? utf8Bytes("\n\n") : 0;
    const tailBytes = utf8Bytes(tailBlock);
    if (tailBytes + tailSeparatorBytes <= remaining) {
      selected.push(tailBlock);
      remaining -= tailBytes + tailSeparatorBytes;
    } else {
      overflowed = true;
    }
  }

  return {
    text: selected.length
      ? selected.join("\n\n")
      : "（没有捕获到完整的近期 User↔Assistant 回合）",
    capture_quality: captureQuality,
    budget_bytes: budgetBytes,
    overflowed,
    sensitive_omitted: sensitiveOmitted,
  };
}

function localEmergencyContinuationText({
  binding,
  pending,
  assistantTail,
  emergencyRecentContext,
  emergencyId,
  emergencyFingerprint,
  capturedAt,
  conversationId = "",
  titleSeed = "",
  reason = "service_unavailable",
}) {
  const laneId = binding?.ready ? String(binding?.laneId || "") : "";
  const savedVersion = Number.isInteger(binding?.savedVersion)
    ? binding.savedVersion
    : null;
  const hasCanonicalBaseline = Boolean(
    laneId && savedVersion != null && binding?.ready
  );
  const pendingView = emergencyPendingView(
    pending,
    hasCanonicalBaseline
  );
  const pendingItems = pendingView.items;
  const pendingText = pendingItems.length
    ? pendingItems
        .map((item, index) =>
          [
            "[pending-user-" + (index + 1) + "]",
            "@id " + String(item.turnId || "unknown"),
            Number.isFinite(Number(item.capturedAt))
              ? "@captured-at " + new Date(Number(item.capturedAt)).toISOString()
              : "",
            "@user-evidence user_message",
            compactEmbeddedEmergencyUserContent(item.content),
          ].join("\n")
        )
        .join("\n\n")
    : "（没有捕获到本地 pending user）";
  const recentBudget = Math.max(
    2 * 1024,
    Math.min(
      LOCAL_EMERGENCY_RECENT_MAX_BYTES,
      LOCAL_EMERGENCY_MAX_BYTES - utf8Bytes(pendingText) - 12 * 1024
    )
  );
  let recent = emergencyRecentContextText(
    emergencyRecentContext,
    pending,
    assistantTail,
    recentBudget
  );

  const buildEnvelope = (recentValue) => [
    cleanTitleSeed(titleSeed || binding?.titleSeed || "Memory V5 本地应急续聊"),
    "",
    "[memory-v5-local-emergency]",
    "[memory-v5-emergency-id:" + emergencyId + "]",
    "[memory-v5-emergency-fingerprint:" + emergencyFingerprint + "]",
    "[memory-v5-captured-at:" + capturedAt + "]",
    laneId ? "[memory-v5-lane:" + laneId + "]" : "",
    savedVersion != null ? "[memory-v5-version:" + savedVersion + "]" : "",
    conversationId ? "[memory-v5-source-chat:" + conversationId + "]" : "",
    binding?.lastSyncKey
      ? "[memory-v5-save-boundary:" + String(binding.lastSyncKey) + "]"
      : "",
    "",
    "这是本地应急续聊包，不是 canonical checkpoint，也不是正式 handoff token。",
    "故障原因：" + String(reason || "service_unavailable"),
    "@EmergencyId " + emergencyId,
    "@EmergencyFingerprint " + emergencyFingerprint,
    "@CapturedAt " + capturedAt,
    laneId ? "@Lane " + laneId : "@Lane 未确认",
    savedVersion != null ? "@Version " + savedVersion : "@Version 未确认",
    conversationId ? "@Chat " + conversationId : "@Chat 未确认",
    binding?.lastSyncKey
      ? "@SaveBoundary " + String(binding.lastSyncKey)
      : "@SaveBoundary 未确认",
    pending?.overflowed
      ? "警告：本地 pending user 可能因容量或敏感信息省略而不完整。"
      : "",
    Number(pending?.sensitive_omitted || 0) > 0
      ? "警告：有 " + Number(pending.sensitive_omitted) + " 条敏感用户内容未写入本地包。"
      : "",
    "",
    "@RecoveryScope " + (hasCanonicalBaseline
      ? "canonical_plus_local_delta"
      : "recent_unanchored_only"),
    "",
    "【本地未同步用户请求】",
    "@pending_scope " + pendingView.scope,
    pendingView.omitted_before > 0
      ? "@pending_omitted_before " + pendingView.omitted_before
      : "",
    pendingText,
    "",
    "【最近关键聊天｜最多 3 个回合｜结构化优先｜总计最多 16KB】",
    "@capture_quality " + recentValue.capture_quality,
    "@recent_budget_bytes " + recentValue.budget_bytes,
    recentValue.overflowed ? "@recent_context_overflow true" : "",
    recentValue.sensitive_omitted > 0
      ? "@recent_sensitive_omitted " + recentValue.sensitive_omitted
      : "",
    recentValue.text,
    "",
    "要求：",
    "1. 先用以上内容临时续聊。pending user / recent user 只证明“用户发送了这条消息”：其中用户直接表达的指令、决定、自述动作可按 user-reported 处理；但消息里粘贴/引用/转述的 Assistant 回复、附件内容、旧 Emergency 包或其他外部材料一律属于 user_provided_unverified_context，除非用户明确背书，否则不得当作用户确认事实。所有 recent Assistant 内容一律是 unconfirmed_context，只能作为待核验线索和工作位置提示；未经当前 Chat 重新验证的内容不得出现在“已确认事实/当前可确认/已完成结论”中。若 @capture_quality degraded_surface 或 evidence=surface_parsed_unverified，则页面只能提供顺序/上下文线索，连 user/assistant 角色归属也不得作为确认事实。若 @round_complete unknown，表示降级页面无法证明该回合完整，禁止根据缺失尾部推断结论。若无法判断某句话是用户直接陈述还是引用内容，按未确认处理。",
    laneId
      ? "2. Memory V5 恢复后，必须对精确 Lane " + laneId + " 执行 resume_lane，并与上述 @Version 校准；禁止按标题猜其他 Lane。"
      : "2. 当前没有已确认 Lane；Memory V5 恢复后必须重新建立/确认 canonical 身份，禁止按标题猜 Lane。",
    savedVersion != null
      ? "3. @Version " + savedVersion + " 是 Emergency 的 canonical 基线；本包中的 pending user 与最近关键聊天属于该基线后的临时 delta。若恢复后的 canonical 仍为该版本，先合并 delta 再保存新 checkpoint；若 canonical 已前进到其他版本，必须先报告版本冲突并人工/工具校准，禁止用任一侧静默覆盖另一侧。"
      : "3. 当前没有已确认 canonical version；云端恢复后必须先建立基线，再把本包作为临时 delta 校准，禁止直接覆盖 canonical。",
    "4. 本地应急包只用于故障期间过渡，不替代 Memory V5 canonical 状态。Emergency 不携带附件文件本体、连接器对象或外部工具状态；如果任务依赖附件/文件/外部状态，新 Chat 必须重新取得这些来源，不能因为用户消息里提到“附件”就假定附件已恢复。",
    "5. @EmergencyFingerprint 相同表示恢复载荷相同；重复看到相同 fingerprint 时不得把同一批 pending user 当成新的请求再次执行。",
    !hasCanonicalBaseline && pendingView.omitted_before > 0
      ? "6. 当前是 recent_unanchored_only，且更早有 " + pendingView.omitted_before + " 条用户消息未包含；不得据此宣称完整恢复，也不得猜测被省略内容。"
      : "",
  ].filter(Boolean).join("\n");

  let envelope = buildEnvelope(recent);
  if (utf8Bytes(envelope) > LOCAL_EMERGENCY_MAX_BYTES) {
    recent = emergencyRecentContextText(
      emergencyRecentContext,
      pending,
      assistantTail,
      0
    );
    envelope = buildEnvelope({
      ...recent,
      text: "（最近关键聊天因 Emergency 总包容量上限已省略；pending user 与身份锚点优先保留。）",
      overflowed: true,
    });
  }
  return envelope;
}

async function copyLocalEmergency({
  binding,
  pending,
  assistantTail,
  emergencyRecentContext,
  conversationId,
  titleSeed,
  reason,
  normalContinuation = false,
}) {
  const emergencyId = "emg_" + randomUrlSafe(12);
  const capturedAt = new Date().toISOString();
  const hasCanonicalBaseline = Boolean(
    binding?.ready &&
    binding?.laneId &&
    Number.isInteger(binding?.savedVersion)
  );
  const fingerprintPendingView = emergencyPendingView(
    pending,
    hasCanonicalBaseline
  );
  const emergencyFingerprint = (
    await sha256UrlSafe(JSON.stringify({
      laneId: hasCanonicalBaseline ? String(binding?.laneId || "") : "",
      savedVersion: hasCanonicalBaseline ? binding.savedVersion : null,
      sourceConversationId: String(conversationId || ""),
      saveBoundary: hasCanonicalBaseline
        ? String(binding?.lastSyncKey || "")
        : "",
      pendingScope: fingerprintPendingView.scope,
      pendingOmittedBefore: fingerprintPendingView.omitted_before,
      pendingOverflowed: Boolean(pending?.overflowed),
      pendingSensitiveOmitted: Number(pending?.sensitive_omitted || 0),
      pending: fingerprintPendingView.items.map((item) => ({
        turnId: String(item?.turnId || ""),
        content: emergencyDedupCanonical(item?.content),
      })),
      captureQuality: String(
        emergencyRecentContext?.capture_quality || "unavailable"
      ),
      recentOverflowed: Boolean(emergencyRecentContext?.overflowed),
      recent: Array.isArray(emergencyRecentContext?.rounds)
        ? emergencyRecentContext.rounds.slice(-3).map((round) => ({
            userId: String(round?.user?.turnId || ""),
            user: emergencyDedupCanonical(round?.user?.content),
            userTruncated: Boolean(round?.user?.truncated),
            userCompleteness: String(round?.user?.completeness || ""),
            assistantId: String(round?.assistant?.turnId || ""),
            assistant: emergencyDedupCanonical(round?.assistant?.content),
            assistantTruncated: Boolean(round?.assistant?.truncated),
            assistantCompleteness: String(
              round?.assistant?.completeness || ""
            ),
          }))
        : [],
      assistantTail: assistantTail?.generation_in_progress
        ? emergencyDedupCanonical(assistantTail?.content)
        : "",
    }))
  ).slice(0, 24);
  const text = localEmergencyContinuationText({
    binding,
    pending,
    assistantTail,
    emergencyRecentContext,
    emergencyId,
    emergencyFingerprint,
    capturedAt,
    conversationId,
    titleSeed,
    reason,
  });
  await copyWithOffscreen(text);
  return pageUi(
    normalContinuation ? "locked" : "degraded",
    normalContinuation
      ? "已复制续聊信息"
      : "正式续聊暂不可用 · 已复制应急续聊内容",
    normalContinuation
      ? "请打开新 Chat 后粘贴发送。当前没有可验证的 canonical binding，因此本次使用有界本地上下文恢复。"
      : "新建 Chat 后可以临时粘贴继续；服务恢复后 Memory V5 会重新校准正式任务状态。",
    false,
    {
      emergencyLocal: !normalContinuation,
      localContinuationCopied: normalContinuation,
      emergencyFingerprint,
      reason: String(reason || ""),
    }
  );
}

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_PATH);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [offscreenUrl],
  });
  if (contexts.length > 0) return;

  if (!offscreenCreating) {
    offscreenCreating = chrome.offscreen.createDocument({
      url: OFFSCREEN_PATH,
      reasons: ["CLIPBOARD"],
      justification: "Copy the one-time Memory V5 handoff command without exposing it to the ChatGPT page.",
    }).finally(() => {
      offscreenCreating = null;
    });
  }
  await offscreenCreating;
}

async function copyWithOffscreen(text) {
  await ensureOffscreenDocument();
  const response = await chrome.runtime.sendMessage({
    target: "offscreen",
    type: "OFFSCREEN_COPY",
    text: String(text || ""),
  });
  if (!response?.ok) throw new Error(response?.error || "clipboard_copy_failed");
  return true;
}

async function detectUniqueCanonicalMarkerInTab(tabId) {
  if (!Number.isInteger(tabId)) return null;
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const userTurns = [
        ...document.querySelectorAll('[data-message-author-role="user"]'),
      ];
      const markers = [];
      for (const node of userTurns) {
        const text = String(node.innerText || node.textContent || "");
        if (
          !/(?:只)?使用已连接的\s*Memory V5 Beta/i.test(text) ||
          !/(?:精确恢复(?:并锁定)?原任务线|精确恢复此任务)/.test(text)
        ) {
          continue;
        }
        const token = text.match(
          /\[memory-v5-handoff:([A-Za-z0-9_-]+)\]/
        )?.[1];
        const laneId = text.match(
          /\[memory-v5-lane:(lane_[A-Za-z0-9_-]+)\]/
        )?.[1];
        const versionRaw = text.match(
          /\[memory-v5-version:(\d+)\]/
        )?.[1];
        if (!token || !laneId) continue;
        markers.push({
          token,
          laneId,
          savedVersion:
            versionRaw != null && Number.isSafeInteger(Number(versionRaw))
              ? Number(versionRaw)
              : null,
        });
      }
      const lanes = [...new Set(markers.map((item) => item.laneId))];
      const versions = [
        ...new Set(
          markers
            .map((item) => item.savedVersion)
            .filter((value) => Number.isSafeInteger(value))
        ),
      ];
      if (lanes.length !== 1 || versions.length > 1) return null;
      const tokens = [...new Set(markers.map((item) => item.token))];
      if (tokens.length !== 1) return null;
      return {
        token: tokens[0],
        laneId: lanes[0],
        savedVersion: versions.length === 1 ? versions[0] : null,
      };
    },
  }).catch(() => []);
  const marker = results?.[0]?.result;
  if (
    !marker ||
    typeof marker.laneId !== "string" ||
    !marker.laneId.startsWith("lane_")
  ) {
    return null;
  }
  return {
    token:
      typeof marker.token === "string" && marker.token
        ? marker.token
        : null,
    laneId: marker.laneId,
    savedVersion: Number.isSafeInteger(marker.savedVersion)
      ? marker.savedVersion
      : null,
  };
}

async function resolveBindingForPage(conversationId, titleSeed = "", tabId = null) {
  if (!conversationId) return null;
  const existing = await getBinding(conversationId);

  // A canonical handoff marker in the current Chat is stronger evidence than a
  // stale browser cache and may safely repair that cache without cloud traffic.
  if (Number.isInteger(tabId)) {
    const exactMarker = await detectUniqueCanonicalMarkerInTab(tabId);
    if (exactMarker?.laneId) {
      if (
        !existing?.laneId ||
        existing.laneId !== exactMarker.laneId ||
        (
          Number.isSafeInteger(exactMarker.savedVersion) &&
          existing.savedVersion !== exactMarker.savedVersion
        ) ||
        existing.readinessSource !== "canonical_handoff"
      ) {
        return setBinding(
          conversationId,
          exactMarker.laneId,
          titleSeed,
          {
            ready: true,
            savedVersion: exactMarker.savedVersion,
            lastSyncKey: "",
            readinessSource: "canonical_handoff",
          }
        );
      }
      return existing;
    }
  }

  return existing?.laneId ? existing : null;
}

async function reconcileRemoteBinding(
  conversationId,
  titleSeed = ""
) {
  if (!conversationId) return null;
  const result = await companionPost("/companion/binding/get", {
    source_conversation_id: conversationId,
  });
  if (!result?.binding?.lane_id || !result?.lane_id) {
    return null;
  }

  const ready = Boolean(result.ready);
  return setBinding(
    conversationId,
    result.lane_id,
    titleSeed,
    {
      ready,
      savedVersion: Number.isSafeInteger(result.current_version)
        ? result.current_version
        : null,
      lastSyncKey: "",
      readinessSource: "remote_binding",
      lifecycleState: String(result.lifecycle_state || ""),
      resumeConfirmationRequired: Boolean(
        result.resume_confirmation_required
      ),
    }
  );
}

async function reconcileActiveSourceHandoff(conversationId) {
  const active = await activeHandoffGet(conversationId);
  if (!active?.token) return { state: "none" };

  let status;
  try {
    status = await companionPost("/companion/handoff/status", {
      token: active.token,
    });
  } catch (error) {
    const reason = String(error?.message || error);
    if (reason === "handoff_not_found") {
      await activeHandoffClear(conversationId);
      return { state: "missing" };
    }
    throw error;
  }

  if (status?.confirmed) {
    const boundaryAt = Number(active.boundaryAt || 0);
    if (boundaryAt > 0) {
      await localPendingClearThrough(conversationId, boundaryAt);
    }
    const remaining = await localPendingGet(conversationId);
    await activeHandoffClear(conversationId);
    const diverged =
      remaining.items.length > 0 ||
      remaining.overflowed ||
      Number(remaining.sensitiveOmitted || 0) > 0;
    return {
      state: diverged ? "retired_diverged" : "retired",
      laneId: status.lane_id || active.laneId || null,
      confirmedVersion:
        Number.isInteger(status.confirmed_version)
          ? status.confirmed_version
          : null,
    };
  }

  if (status?.handoff_status === "expired") {
    await activeHandoffClear(conversationId);
    return { state: "expired" };
  }

  if (
    status?.handoff_status === "consumed" ||
    status?.target_bound
  ) {
    return {
      state: "waiting_confirmation",
      laneId: status.lane_id || active.laneId || null,
    };
  }

  return { state: "replaceable_pending" };
}

async function ensureRemoteConversationLane(
  conversationId,
  titleSeed = ""
) {
  if (!conversationId) throw new Error("conversation_id_missing");
  const result = await companionPost("/companion/binding/ensure", {
    source_conversation_id: conversationId,
    title_seed: String(titleSeed || "").slice(0, 120),
  });
  if (!result?.lane_id || !result?.binding?.lane_id) {
    throw new Error("binding_ensure_failed");
  }
  if (result.lane_id !== result.binding.lane_id) {
    throw new Error("binding_ensure_mismatch");
  }
  return setBinding(
    conversationId,
    result.lane_id,
    titleSeed,
    {
      ready: Boolean(result.ready),
      savedVersion: Number.isSafeInteger(result.current_version)
        ? result.current_version
        : null,
      lastSyncKey: "",
      readinessSource: "remote_binding",
      lifecycleState: String(result.lifecycle_state || ""),
      resumeConfirmationRequired: Boolean(
        result.resume_confirmation_required
      ),
    }
  );
}

async function verifiedLocalLaneHint(binding) {
  if (!binding?.ready || !binding?.laneId) return null;

  if (binding.readinessSource === "canonical_handoff") {
    return binding.laneId;
  }

  if (
    binding.readinessSource === "checkpoint_sync" &&
    binding.lastSyncKey
  ) {
    const status = await companionPost(
      "/companion/checkpoint/status",
      { idempotency_key: String(binding.lastSyncKey) }
    );
    if (
      status?.completed &&
      status?.lane_id === binding.laneId
    ) {
      return binding.laneId;
    }
  }

  return null;
}

function pageUi(state, title = "", toast = "", toastError = false, extra = {}) {
  return { state, title, toast, toastError, ...extra };
}

async function pageStatus(context = {}, sender = {}) {
  const conversationId = context.conversationId || null;
  if (!conversationId) {
    return pageUi("idle", "Power · 发送第一条消息后可一键续聊");
  }

  await resolveBindingForPage(
    conversationId,
    context.titleSeed || "",
    sender?.tab?.id
  );
  const health = await backendHealthGet();
  const cloudBlocked =
    health && Number(health.blockedUntil || 0) > Date.now();
  const activeSave = await saveBoundaryCurrent(conversationId);

  if (
    !cloudBlocked &&
    activeSave?.status === "pending" &&
    !String(activeSave.syncKey || "").startsWith(POWER_SYNC_PREFIX) &&
    Number(activeSave.attempts || 0) < 3
  ) {
    return pageUi("busy", "正在保存…");
  }

  if (cloudBlocked) {
    return pageUi(
      "degraded",
      "服务暂不可用 · 点击使用应急续聊"
    );
  }

  const auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    return pageUi("auth", "点击连接 Memory V5");
  }

  return pageUi("idle", "Power · 点击复制续聊信息");
}

async function pageSend(message, sender = {}) {
  const text = String(message.text || "").trim();
  if (!text) return pageStatus(message.context || {}, sender);
  const controlSyncKey = text.match(CONTROL_SYNC_RE)?.[1] || null;

  const context = message.context || {};
  const conversationId = context.conversationId || null;
  const titleSeed = cleanTitleSeed(context.titleSeed || text);
  const markers = handoffMarkers(text);

  if (controlSyncKey) {
    if (
      controlSyncKey.startsWith(POWER_SYNC_PREFIX) &&
      String(message.source || "") !== "power_one_click"
    ) {
      return pageUi(
        "error",
        "这不是续聊内容",
        "这是旧窗口里的 Power 内部保存指令。请使用 Power 成功后自动复制的正式续聊内容。",
        true,
        { controlSyncRejected: true }
      );
    }
    if (!conversationId) {
      return pageUi("busy", "等待 ChatGPT 分配当前 Chat 身份…");
    }
    const boundary = await saveBoundarySet(
      conversationId,
      controlSyncKey
    );
    const binding = await resolveBindingForPage(
      conversationId,
      titleSeed,
      sender?.tab?.id
    );

    if (!boundary.registered) {
      const auth = await authStatus();
      if (auth.configured && auth.authenticated) {
        // First ask the server to reconcile any authoritative remote binding.
        // Never let a browser cache overwrite it.
        let registered = await companionPost(
          "/companion/control-sync/register",
          {
            source_conversation_id: conversationId,
            sync_key: controlSyncKey,
            lane_id: null,
          }
        );

        let remoteLaneId =
          registered?.lane_id ||
          registered?.binding?.lane_id ||
          null;

        // Legacy clients may have a valid local canonical proof but no durable
        // remote binding. Migrate only after verifying that proof.
        if (!remoteLaneId && binding?.ready && binding?.laneId) {
          const verifiedLaneId = await verifiedLocalLaneHint(binding);
          if (verifiedLaneId) {
            registered = await companionPost(
              "/companion/control-sync/register",
              {
                source_conversation_id: conversationId,
                sync_key: controlSyncKey,
                lane_id: verifiedLaneId,
              }
            );
            remoteLaneId =
              registered?.lane_id ||
              registered?.binding?.lane_id ||
              null;
          }
        }

        const remotelyRegistered =
          registered?.sync?.status === "ok" &&
          Boolean(remoteLaneId);

        if (remoteLaneId) {
          const remoteReady = Boolean(registered?.ready);
          await setBinding(
            conversationId,
            remoteLaneId,
            titleSeed,
            {
              ready: remoteReady,
              savedVersion: Number.isSafeInteger(registered?.current_version)
                ? registered.current_version
                : null,
              lastSyncKey: "",
              readinessSource: remoteReady ? "remote_binding" : "",
            }
          );
        }

        if (registered?.checkpoint_sync?.completed) {
          await saveBoundaryClear(
            conversationId,
            controlSyncKey
          );
          return pageUi(
            remoteLaneId && registered?.ready ? "locked" : "idle",
            "这次保存已经完成 · 已忽略重复请求",
            "没有清除保存完成之后的新消息；需要再次续聊时，直接重新点击 Power。",
            false,
            {
              completed: true,
              syncTerminal: true,
              duplicateSync: true,
              laneId: remoteLaneId,
              savedVersion:
                registered?.checkpoint_sync?.saved_version ?? null,
            }
          );
        }

        if (remotelyRegistered) {
          await saveBoundaryUpdate(
            conversationId,
            controlSyncKey,
            { registered: true }
          );
        }
      }
    }
    return pageUi("busy", "等待 Memory V5 显式保存完成…");
  }

  if (
    markers.kind === "v4" ||
    markers.kind === "legacy_v5" ||
    markers.kind === "quoted_v5"
  ) {
    return pageStatus(context, sender);
  }
  if (
    markers.kind === "malformed_v5" ||
    markers.kind === "malformed_legacy"
  ) {
    return pageUi("error", "续聊标记不完整，未写入 Memory V5");
  }

  if (
    markers.kind === "local_emergency" ||
    markers.kind === "local_emergency_unbound"
  ) {
    return pageStatus(context, sender);
  }

  if (
    markers.kind === "v5" &&
    markers.token &&
    markers.laneId &&
    Number.isSafeInteger(markers.savedVersion)
  ) {
    if (!conversationId) {
      await enqueuePendingTab(sender?.tab?.id, {
        kind: "bind",
        token: markers.token,
        laneId: markers.laneId,
        titleSeed,
        ready: true,
        savedVersion: markers.savedVersion,
        readinessSource: "canonical_handoff",
      });
      return pageUi("busy", "等待 ChatGPT 分配当前 Chat 身份…");
    }

    try {
      await bindConversationFromHandoffProof({
        conversationId,
        token: markers.token,
        laneId: markers.laneId,
        savedVersion: markers.savedVersion,
        titleSeed,
      });
    } catch (error) {
      const reason = String(error?.message || error);
      if (isTransientServiceError(reason)) {
        return pageUi(
          "degraded",
          "续聊已发送，但远端绑定暂未确认",
          "当前 Chat 可以继续恢复；Power 不会猜测任务，服务恢复后再重试即可。",
          false,
          { bindingPending: true }
        );
      }
      return pageUi(
        "error",
        "续聊身份验证失败",
        "Power 没有建立错误绑定。请确认粘贴的是刚复制的完整续聊内容。",
        true,
        {
          bindingRejected: true,
          reason,
        }
      );
    }
    return pageStatus(context, sender);
  }

  const turnId = String(message.turnId || ("page_" + crypto.randomUUID()));
  if (!conversationId) {
    await enqueuePendingTab(sender?.tab?.id, {
      kind: "turn",
      turnId,
      content: text,
      titleSeed,
    });
    return pageUi("busy", "等待 ChatGPT 分配当前 Chat 身份…");
  }

  await localPendingAdd(conversationId, {
    turnId,
    content: text,
    titleSeed,
    capturedAt: Date.now(),
  });
  return pageUi(
    "idle",
    "Power · 点击复制续聊信息"
  );
}

async function pageControlSync(message) {
  const auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    return pageUi("auth", "点击连接 Memory V5", "", false, { completed: false });
  }

  const context = message.context || {};
  const conversationId = context.conversationId || null;
  if (!conversationId) {
    return pageUi("busy", "等待 ChatGPT 分配当前 Chat 身份…", "", false, { completed: false });
  }

  const syncKey = String(message.idempotencyKey || "").trim();
  if (!/^[A-Za-z0-9_-]{8,200}$/.test(syncKey)) {
    throw new Error("invalid_sync_key");
  }

  const binding = await getBinding(conversationId);
  if (
    binding?.ready &&
    binding.lastSyncKey &&
    binding.lastSyncKey === syncKey
  ) {
    const completedBoundary = await saveBoundaryGet(
      conversationId,
      syncKey
    );
    if (completedBoundary) {
      await localPendingClearThrough(
        conversationId,
        Number(completedBoundary.capturedAt)
      );
      await saveBoundaryClear(conversationId, syncKey);
    }
    return pageUi(
      "locked",
      "点击复制 Memory V5 续聊指令",
      "",
      false,
      {
        completed: true,
        canonicalReady: true,
        laneId: binding.laneId,
        savedVersion: binding.savedVersion ?? null,
        localSyncCache: true,
      }
    );
  }

  const boundary = await saveBoundaryGet(conversationId, syncKey);
  if (!boundary) {
    return pageUi(
      binding?.ready ? "locked" : "idle",
      binding?.ready
        ? "点击复制 Memory V5 续聊指令"
        : "历史保存标记已忽略",
      "",
      false,
      { completed: false, syncTerminal: true }
    );
  }
  if (
    boundary.status === "stopped" ||
    Number(boundary.attempts || 0) >= 3
  ) {
    return pageUi(
      "idle",
      "保存同步已停止 · 需要时重新显式保存",
      "",
      false,
      { completed: false, syncTerminal: true }
    );
  }

  const attempts = Number(boundary.attempts || 0) + 1;
  await saveBoundaryUpdate(
    conversationId,
    syncKey,
    { attempts }
  );

  const status = await companionPost(
    "/companion/checkpoint/status",
    { idempotency_key: syncKey },
    { automatic: true }
  );
  if (status?.completed && status?.lane_id) {
    // Save completion is not enough to make a Chat canonical-ready. Confirm
    // the durable remote Conversation→Lane binding and current identity state
    // every time before clearing local recovery data.
    const registered = await companionPost(
      "/companion/control-sync/register",
      {
        source_conversation_id: conversationId,
        sync_key: syncKey,
        lane_id: status.lane_id,
      }
    );
    const remoteLaneId =
      registered?.lane_id ||
      registered?.binding?.lane_id ||
      null;
    if (
      registered?.sync?.status !== "ok" ||
      remoteLaneId !== status.lane_id
    ) {
      throw new Error("checkpoint_sync_binding_mismatch");
    }
    await saveBoundaryUpdate(
      conversationId,
      syncKey,
      { registered: true }
    );

    const remoteVersion = Number.isSafeInteger(registered?.current_version)
      ? registered.current_version
      : Number.isSafeInteger(status.saved_version)
        ? status.saved_version
        : null;

    if (!registered?.ready) {
      await setBinding(
        conversationId,
        status.lane_id,
        context.titleSeed || "",
        {
          ready: false,
          savedVersion: remoteVersion,
          lastSyncKey: "",
          readinessSource: "",
        }
      );
      await saveBoundaryClear(conversationId, syncKey);
      return pageUi(
        "idle",
        "已保存，但任务身份还不能安全确认",
        "本地恢复数据已保留。Power 不会猜测任务；请重新点击 Power 再试。",
        false,
        {
          completed: true,
          canonicalReady: false,
          syncTerminal: true,
          laneId: status.lane_id,
          savedVersion: remoteVersion,
        }
      );
    }

    const exactSyncVersion =
      Number.isSafeInteger(status.saved_version) &&
      Number.isSafeInteger(remoteVersion) &&
      remoteVersion === status.saved_version;

    await setBinding(
      conversationId,
      status.lane_id,
      context.titleSeed || "",
      {
        ready: true,
        savedVersion: remoteVersion,
        lastSyncKey: exactSyncVersion ? syncKey : "",
        readinessSource: exactSyncVersion
          ? "checkpoint_sync"
          : "remote_binding",
      }
    );
    await localPendingClearThrough(
      conversationId,
      Number(boundary.capturedAt)
    );
    await saveBoundaryClear(conversationId, syncKey);
    return pageUi(
      "locked",
      "点击复制 Memory V5 续聊指令",
      "Memory V5 已保存，Power 已同步。",
      false,
      {
        completed: true,
        canonicalReady: true,
        laneId: status.lane_id,
        savedVersion: remoteVersion,
      }
    );
  }

  if (attempts >= 3) {
    await saveBoundaryUpdate(
      conversationId,
      syncKey,
      { status: "stopped" }
    );
    return pageUi(
      "idle",
      "保存同步已停止 · 需要时重新显式保存",
      "",
      false,
      { completed: false, syncTerminal: true }
    );
  }

  return pageUi(
    "busy",
    "等待 Memory V5 显式保存完成…",
    "",
    false,
    { completed: false }
  );
}

async function pageClick(message, sender = {}) {
  const context = message.context || {};
  const conversationId = context.conversationId || null;
  if (!conversationId) {
    return pageUi("idle", "当前还没有可绑定的 Chat");
  }

  let binding = await resolveBindingForPage(
    conversationId,
    context.titleSeed || "",
    sender?.tab?.id
  );

  const pending = pendingForHandoff(
    await localPendingGet(conversationId),
    message.pendingUser || message.pendingUserSnapshot
  );
  const assistantTail =
    message.assistantTail && typeof message.assistantTail === "object"
      ? message.assistantTail
      : null;
  const emergencyRecentContext =
    message.emergencyRecentContext &&
    typeof message.emergencyRecentContext === "object"
      ? message.emergencyRecentContext
      : null;

  const health = await backendHealthGet();
  if (
    health &&
    Number(health.blockedUntil || 0) > Date.now()
  ) {
    return copyLocalEmergency({
      binding,
      pending,
      assistantTail,
      emergencyRecentContext,
      conversationId,
      titleSeed: context.titleSeed || binding?.titleSeed || "",
      reason: String(health.reason || "service_unavailable"),
    });
  }

  let auth = await authStatus();
  if (!auth.configured || !auth.authenticated) {
    try {
      await login();
      auth = await authStatus();
    } catch (error) {
      return copyLocalEmergency({
        binding,
        pending,
        assistantTail,
        emergencyRecentContext,
        conversationId,
        titleSeed: context.titleSeed || binding?.titleSeed || "",
        reason: "auth_unavailable:" + String(error?.message || error),
      });
    }
  }

  try {
    const sourceHandoff = await reconcileActiveSourceHandoff(conversationId);
    if (sourceHandoff.state === "waiting_confirmation") {
      return pageUi(
        "idle",
        "续聊已交接，等待新 Chat 确认",
        "请先在新 Chat 完成恢复确认。旧窗口不会再创建第二条任务主线。",
        false,
        {
          sourceHandoffPending: true,
          laneId: sourceHandoff.laneId || null,
        }
      );
    }
    if (sourceHandoff.state === "retired_diverged") {
      return pageUi(
        "error",
        "旧窗口在交接后又产生了新内容",
        "新 Chat 已确认接管任务；这些旧窗口新增内容没有自动合并。请在新 Chat 中人工确认是否需要补充。",
        true,
        {
          sourceConversationRetired: true,
          sourceDiverged: true,
          laneId: sourceHandoff.laneId || null,
          confirmedVersion: sourceHandoff.confirmedVersion,
        }
      );
    }
    if (sourceHandoff.state === "retired") {
      return pageUi(
        "idle",
        "此窗口已完成交接",
        "请继续使用已确认的新 Chat。旧窗口不会重新成为任务主线。",
        false,
        {
          sourceConversationRetired: true,
          laneId: sourceHandoff.laneId || null,
          confirmedVersion: sourceHandoff.confirmedVersion,
        }
      );
    }
  } catch (error) {
    if (isTransientServiceError(error?.message || error)) {
      return copyLocalEmergency({
        binding,
        pending,
        assistantTail,
        emergencyRecentContext,
        conversationId,
        titleSeed: context.titleSeed || binding?.titleSeed || "",
        reason: String(error?.message || error),
      });
    }
    throw error;
  }

  if (!binding?.laneId || !binding.ready) {
    try {
      const reconciled = await reconcileRemoteBinding(
        conversationId,
        context.titleSeed || binding?.titleSeed || ""
      );
      if (reconciled?.laneId) {
        binding = reconciled;
      } else if (binding?.laneId) {
        await clearBinding(conversationId);
        binding = null;
      }

      if (!binding?.laneId) {
        binding = await ensureRemoteConversationLane(
          conversationId,
          context.titleSeed || ""
        );
      }
    } catch (error) {
      if (isTransientServiceError(error?.message || error)) {
        return copyLocalEmergency({
          binding,
          pending,
          assistantTail,
          emergencyRecentContext,
          conversationId,
          titleSeed: context.titleSeed || binding?.titleSeed || "",
          reason: String(error?.message || error),
        });
      }
      throw error;
    }
  }

  if (binding?.resumeConfirmationRequired) {
    return pageUi(
      "idle",
      "请先确认当前恢复摘要",
      "当前续聊已经恢复，但还没有完成确认。确认后再点 Power 即可继续下一次续聊。",
      false,
      {
        resumeConfirmationRequired: true,
        laneId: binding.laneId || null,
        savedVersion: Number.isInteger(binding.savedVersion)
          ? binding.savedVersion
          : null,
      }
    );
  }

  if (
    !binding?.laneId ||
    (
      !binding.ready &&
      binding.lifecycleState !== "provisional"
    )
  ) {
    throw new Error("binding_not_ready");
  }

  if (
    binding?.readinessSource === "canonical_handoff" &&
    Number.isInteger(sender?.tab?.id)
  ) {
    const marker = await detectUniqueCanonicalMarkerInTab(sender.tab.id);
    if (
      marker?.token &&
      marker.laneId === binding.laneId &&
      Number.isSafeInteger(marker.savedVersion)
    ) {
      try {
        binding = await bindConversationFromHandoffProof({
          conversationId,
          token: marker.token,
          laneId: marker.laneId,
          savedVersion: marker.savedVersion,
          titleSeed: context.titleSeed || binding?.titleSeed || "",
        });
      } catch (proofError) {
        if (isTransientServiceError(proofError?.message || proofError)) {
          return copyLocalEmergency({
            binding,
            pending,
            assistantTail,
            emergencyRecentContext,
            conversationId,
            titleSeed: context.titleSeed || binding?.titleSeed || "",
            reason: String(proofError?.message || proofError),
          });
        }
        try {
          const reconciled = await reconcileRemoteBinding(
            conversationId,
            context.titleSeed || binding?.titleSeed || ""
          );
          if (reconciled?.laneId && reconciled.ready) {
            binding = reconciled;
          } else {
            await clearBinding(conversationId);
            binding = null;
          }
        } catch (reconcileError) {
          if (isTransientServiceError(reconcileError?.message || reconcileError)) {
            return copyLocalEmergency({
              binding,
              pending,
              assistantTail,
              emergencyRecentContext,
              conversationId,
              titleSeed: context.titleSeed || binding?.titleSeed || "",
              reason: String(reconcileError?.message || reconcileError),
            });
          }
          throw reconcileError;
        }
      }
    }
  }

  if (binding?.resumeConfirmationRequired) {
    return pageUi(
      "idle",
      "请先确认当前恢复摘要",
      "当前续聊已经恢复，但还没有完成确认。确认后再点 Power 即可继续下一次续聊。",
      false,
      {
        resumeConfirmationRequired: true,
        laneId: binding.laneId || null,
        savedVersion: Number.isInteger(binding.savedVersion)
          ? binding.savedVersion
          : null,
      }
    );
  }

  if (
    !binding?.laneId ||
    (
      !binding.ready &&
      binding.lifecycleState !== "provisional"
    )
  ) {
    throw new Error("binding_not_ready_after_handoff_proof");
  }

  const prepareHandoff = (activeBinding) =>
    companionPost("/companion/handoff/prepare", {
      lane_id: activeBinding.laneId,
      source_conversation_id: conversationId,
      local_pending_user: pending,
      assistant_tail: assistantTail,
    });

  let prepared;
  try {
    prepared = await prepareHandoff(binding);
  } catch (error) {
    const messageText = String(error?.message || error);
    if (
      messageText === "binding_conflict" ||
      messageText === "binding_missing" ||
      messageText === "lane_not_found"
    ) {
      try {
        const reconciled = await reconcileRemoteBinding(
          conversationId,
          context.titleSeed || binding?.titleSeed || ""
        );
        if (reconciled?.laneId) {
          binding = reconciled;
        } else {
          await clearBinding(conversationId);
          binding = await ensureRemoteConversationLane(
            conversationId,
            context.titleSeed || ""
          );
        }

        if (
          binding?.resumeConfirmationRequired
        ) {
          return pageUi(
            "idle",
            "请先确认当前恢复摘要",
            "当前续聊已经恢复，但还没有完成确认。确认后再点 Power 即可继续下一次续聊。",
            false,
            {
              resumeConfirmationRequired: true,
              laneId: binding.laneId || null,
            }
          );
        }
        if (
          !binding?.laneId ||
          (
            !binding.ready &&
            binding.lifecycleState !== "provisional"
          )
        ) {
          throw new Error("binding_not_ready_after_reconcile");
        }
        prepared = await prepareHandoff(binding);
      } catch (reconcileError) {
        if (
          isTransientServiceError(
            reconcileError?.message || reconcileError
          )
        ) {
          return copyLocalEmergency({
            binding,
            pending,
            assistantTail,
            emergencyRecentContext,
            conversationId,
            titleSeed: context.titleSeed || binding?.titleSeed || "",
            reason: String(
              reconcileError?.message || reconcileError
            ),
          });
        }
        throw reconcileError;
      }
    } else if (messageText === "handoff_in_progress") {
      return pageUi(
        "idle",
        "已有一次续聊正在等待确认",
        "请先在目标 Chat 完成恢复确认，再准备下一次续聊。",
        false,
        {
          resumeConfirmationRequired: true,
          laneId: binding?.laneId || null,
        }
      );
    } else if (messageText === "source_conversation_retired") {
      return pageUi(
        "idle",
        "此窗口已完成交接",
        "请继续使用已确认的新 Chat。旧窗口不会重新成为任务主线。",
        false,
        {
          sourceConversationRetired: true,
          laneId: binding?.laneId || null,
        }
      );
    } else if (isTransientServiceError(messageText)) {
      return copyLocalEmergency({
        binding,
        pending,
        assistantTail,
        emergencyRecentContext,
        conversationId,
        titleSeed: context.titleSeed || binding?.titleSeed || "",
        reason: messageText,
      });
    } else {
      throw error;
    }
  }

  if (Number(prepared?.coverage?.pending_user_sensitive_omitted || 0) > 0) {
    return pageUi(
      "error",
      "检测到敏感的未保存内容 · 已停止续聊",
      "为避免泄露或丢失，Power 没有复制正式续聊内容。请处理该敏感内容后重新点击 Power。",
      true,
      {
        continuationUnavailable: true,
        handoffCopied: false,
        reason: "sensitive_pending_not_uploaded",
      }
    );
  }

  const text = continuationText(prepared, {
    titleSeed: context.titleSeed || binding.titleSeed || prepared.task_title || "",
  });
  await copyWithOffscreen(text);

  const boundaryAt = pending.items.reduce(
    (max, item) => Math.max(max, Number(item?.capturedAt || 0)),
    0,
  );
  await activeHandoffSet(conversationId, {
    token: prepared.token,
    laneId: prepared.lane_id,
    snapshotVersion: prepared.snapshot_version,
    boundaryAt,
    expiresAt: prepared.expires_at || null,
  });

  const pendingCount = Number(prepared.pending_turn_count || 0);
  const assistantTailCaptured = Boolean(prepared.assistant_tail_captured);
  const assistantTailStatus = String(prepared.assistant_tail_status || "");
  const diag =
    message.assistantCaptureDiagnostic &&
    typeof message.assistantCaptureDiagnostic === "object"
      ? message.assistantCaptureDiagnostic
      : null;
  const diagText =
    diag && !assistantTailCaptured
      ? " [diag runtime=" + chrome.runtime.getManifest().version +
        " page=" + String(message.pageVersion || "?") +
        " turns=" + Number(diag.turn_containers || 0) +
        " explicitA=" + Number(diag.explicit_assistant || 0) +
        " explicitU=" + Number(diag.explicit_user || 0) +
        " markdown=" + Number(diag.main_markdown || 0) +
        " candidates=" + Number(diag.assistant_candidates || 0) +
        " boundary=" + String(diag.boundary_strategy || "none") +
        " mainChars=" + Number(diag.main_text_chars || 0) + "]"
      : "";
  const tailWarning =
    pendingCount > 0 && !assistantTailCaptured
      ? assistantTailStatus === "omitted_sensitive"
        ? "；检测到高置信秘密，Assistant 工作尾部未保存。"
        : assistantTailStatus === "omitted_too_large"
          ? "；Assistant 工作尾部过长，未保存。"
          : "；未能捕获 Assistant 工作尾部，新 Chat 只能恢复 checkpoint + 用户请求。" + diagText
      : "";
  return pageUi(
    "locked",
    "已保存，续聊内容已复制",
    pendingCount > 0
      ? "已保存，续聊内容已复制；包含 " + pendingCount + " 条尚未纳入 checkpoint 的用户请求" +
        (assistantTailCaptured ? "，并已带上未确认的 Assistant 工作尾部。" : tailWarning)
      : "已保存，续聊内容已复制。请打开新 Chat 后粘贴发送。",
    pendingCount > 0 && !assistantTailCaptured,
    { handoffCopied: true }
  );
}

function externalSenderAllowed(sender) {
  if (!Number.isInteger(sender?.tab?.id)) return false;
  try {
    return new URL(sender.url || "").origin === "https://chatgpt.com";
  } catch {
    return false;
  }
}

async function handleExternal(message, sender = {}) {
  if (!externalSenderAllowed(sender)) throw new Error("external_sender_not_allowed");
  if (message?.namespace !== "memory-v5-power") throw new Error("invalid_external_namespace");

  const tabUrl = String(sender?.tab?.url || sender?.url || "");
  if (Number.isInteger(sender?.tab?.id) && tabUrl.startsWith("https://chatgpt.com/")) {
    tabRouteKeys.set(sender.tab.id, routeKeyFromUrl(tabUrl));
  }
  let pathname = "";
  try { pathname = new URL(tabUrl).pathname; } catch {}
  const trustedContext = {
    conversationId: conversationIdFromUrl(tabUrl),
    titleSeed: cleanTitleSeed(sender?.tab?.title || message?.context?.titleSeed || ""),
    pathname,
  };
  const trustedMessage = {
    ...message,
    context: trustedContext,
  };

  const runtimeVersion = chrome.runtime.getManifest().version;
  const pageVersion = String(trustedMessage.pageVersion || "");
  const stalePage = pageVersion !== runtimeVersion;

  if (trustedMessage.type === "POWER_PAGE_SEND" && stalePage) {
    await storeSendBoundaryInTab(sender.tab.id, {
      conversationId: trustedContext.conversationId,
      userText: trustedMessage.text,
      turnId: trustedMessage.turnId,
    });
    await injectCurrentArchitecture(sender.tab.id);
  }

  if (trustedMessage.type === "POWER_PAGE_CLICK" && stalePage) {
    await injectCurrentArchitecture(sender.tab.id);
    return pageUi(
      "locked",
      "Memory V5 页面脚本已自动更新",
      "页面脚本已更新到 " + runtimeVersion + "；请再次操作。"
    );
  }

  if (trustedMessage.type === "POWER_PAGE_STATUS" && stalePage) {
    await injectCurrentArchitecture(sender.tab.id);
  }

  if (trustedMessage.type === "POWER_PAGE_STATUS") {
    return pageStatus(trustedContext, sender);
  }
  if (trustedMessage.type === "POWER_PAGE_SEND") {
    return pageSend(trustedMessage, sender);
  }
  if (trustedMessage.type === "POWER_CONTROL_SYNC") {
    return pageControlSync(trustedMessage, sender);
  }
  if (trustedMessage.type === "POWER_PAGE_CLICK") {
    return pageClick(trustedMessage, sender);
  }
  throw new Error("unknown_external_message_type");
}

async function handle(message) {
  if (!message || typeof message.type !== "string") {
    throw new Error("invalid_message");
  }

  if (message.type === "POWER_AUTH_STATUS") return authStatus();
  if (message.type === "POWER_DIAG_EVENT") {
    const diag = {
      ...(message.diag && typeof message.diag === "object" ? message.diag : {}),
      receivedAt: new Date().toISOString(),
    };
    await storageSet({ [DIAG_KEY]: diag });
    return { stored: true };
  }
  if (message.type === "POWER_LAST_DIAG") {
    const stored = (await storageGet(DIAG_KEY))[DIAG_KEY] ?? null;
    return { diag: stored };
  }
  if (message.type === "POWER_AUTH_LOGIN") return login();
  if (message.type === "POWER_AUTH_LOGOUT") {
    await storageRemove(AUTH_KEY);
    return { authenticated: false };
  }

  throw new Error("unknown_message_type");
}

chrome.runtime.onInstalled.addListener((details) => {
  rehydrateOpenChatgptTabs(details?.reason || "onInstalled").catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  const url = changeInfo.url || "";
  if (!url.startsWith("https://chatgpt.com/")) return;
  handleTabUrlChange(tabId, url).catch(() => {});
});

chrome.webNavigation.onHistoryStateUpdated.addListener((details) => {
  if (details.frameId !== 0) return;
  if (!String(details.url || "").startsWith("https://chatgpt.com/")) return;
  handleTabUrlChange(details.tabId, details.url, {
    injectOnRouteChange: true,
  }).catch(() => {});
});

chrome.tabs.onRemoved.addListener((tabId) => {
  tabRouteKeys.delete(tabId);
  pendingTabSet(tabId, []).catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target === "offscreen") return false;

  handle(message, sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((error) => sendResponse(externalFailure(error)));
  return true;
});

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  handleExternal(message, sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((error) => sendResponse(externalFailure(error)));
  return true;
});
