globalThis.MEMORY_V5_POWER_CONFIG = {
  apiBase: "https://memory-v5-beta.8084867.workers.dev",
  resource: "https://memory-v5-beta.8084867.workers.dev/mcp",
  authIssuer: "https://punctual-tree-83-staging.authkit.app",
  oauthClientId: "client_01M3AAZA9W2KD0B4PXEMGV9BXA",
  scopes: ["openid", "profile", "email", "offline_access"]
};
