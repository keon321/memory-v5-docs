(() => {
  const AGENT_KEY = "__memoryV5PowerPageAgent";
  const VERSION = "0.7.0";
  // Test-only unpacked extension ID. The current OAuth redirect is already
  // bound to this same ID, so keeping one explicit authority avoids guessing.
  const EXTENSION_ID = "jdkaiddpcibamlnhifconllbpknkaccm";
  const ROOT_ID = "memory-v5-power-root";
  const TOAST_ID = "memory-v5-power-toast";
  const POSITION_KEY = "memory_v5_power_position_v2";
  const ASSISTANT_BOUNDARY_KEY = "memory_v5_assistant_boundary_v1";
  const CONTROL_SYNC_RE = /\[memory-control:sync:([A-Za-z0-9_-]+)\]/g;
  const POWER_SYNC_PREFIX = "mcsync-power-";
  const CONVERSATION_RE = /\/c\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\/|$)/i;

  try { window[AGENT_KEY]?.stop?.(); } catch {}

  const abort = new AbortController();
  let drag = null;
  let lastSend = { text: "", at: 0 };
  let draftTurnId = "";
  let toastTimer = null;
  let syncTimer = null;
  let syncObserver = null;
  let activeSyncKey = "";
  let completedSyncKey = "";
  let failedSyncKey = "";
  let syncAttempts = 0;
  let oneClickTransaction = null;
  let successResetTimer = null;

  document.getElementById(ROOT_ID)?.remove();
  document.getElementById(TOAST_ID)?.remove();

  function promptElement() {
    return (
      document.querySelector("#prompt-textarea") ||
      document.querySelector('[data-testid="composer-text-input"]') ||
      document.querySelector('textarea[placeholder*="ChatGPT"]') ||
      document.querySelector("form textarea") ||
      document.querySelector('[contenteditable="true"][role="textbox"]') ||
      document.querySelector('div[contenteditable="true"]')
    );
  }

  function promptText() {
    const el = promptElement();
    if (!el) return "";
    if ("value" in el && typeof el.value === "string") return el.value.trim();
    return (el.innerText || el.textContent || "").trim();
  }

  function isPromptTarget(target) {
    const el = promptElement();
    if (el && (target === el || el.contains?.(target))) return true;
    return Boolean(
      target?.closest?.(
        '#prompt-textarea,[data-testid="composer-text-input"],textarea,[contenteditable="true"][role="textbox"],div[contenteditable="true"]'
      )
    );
  }

  function isSendButton(target) {
    const button = target?.closest?.("button");
    if (!button) return false;
    if (button.matches('[data-testid="send-button"]')) return true;
    const label = [
      button.getAttribute("aria-label") || "",
      button.getAttribute("title") || "",
    ].join(" ");
    return /发送|send/i.test(label);
  }

  function conversationId() {
    return location.pathname.match(CONVERSATION_RE)?.[1] ?? null;
  }

  function titleSeed() {
    const title = (document.title || "")
      .replace(/\s*[-|]\s*ChatGPT.*$/i, "")
      .replace(/\s+/g, " ")
      .trim();
    return title && !/^chatgpt$/i.test(title) ? title.slice(0, 120) : "";
  }

  function context() {
    return {
      conversationId: conversationId(),
      titleSeed: titleSeed(),
      pathname: location.pathname,
    };
  }

  function utf8Clip(text, maxBytes = 20 * 1024) {
    const value = String(text || "").trim();
    if (!value) return "";
    const encoder = new TextEncoder();
    if (encoder.encode(value).byteLength <= maxBytes) return value;
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(0, mid)).byteLength <= maxBytes) low = mid;
      else high = mid - 1;
    }
    return value.slice(0, low).trim();
  }

  function utf8Tail(text, maxBytes = 16 * 1024) {
    const value = String(text || "").trim();
    if (!value) return "";
    const encoder = new TextEncoder();
    if (encoder.encode(value).byteLength <= maxBytes) return value;
    let low = 0;
    let high = value.length;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (encoder.encode(value.slice(value.length - mid)).byteLength <= maxBytes) low = mid;
      else high = mid - 1;
    }
    return value.slice(value.length - low).trim();
  }

  function conversationSurfaceText() {
    const surface =
      document.querySelector("main") ||
      document.querySelector('[role="main"]') ||
      promptElement()?.closest?.('main,[role="main"]') ||
      document.body ||
      null;
    return surface ? (surface.innerText || surface.textContent || "").trim() : "";
  }

  function storeAssistantBoundary(userText, turnId) {
    const text = String(userText || "").trim();
    if (!text) return;
    const record = {
      conversation_id: conversationId(),
      turn_id: String(turnId || ""),
      user_text: utf8Clip(text, 8 * 1024),
      before_tail: utf8Tail(conversationSurfaceText(), 16 * 1024),
      captured_at: Date.now(),
    };
    try {
      sessionStorage.setItem(ASSISTANT_BOUNDARY_KEY, JSON.stringify(record));
    } catch {}
  }

  function loadAssistantBoundary() {
    try {
      const parsed = JSON.parse(
        sessionStorage.getItem(ASSISTANT_BOUNDARY_KEY) || "null"
      );
      if (!parsed || typeof parsed !== "object") return null;
      if (
        parsed.conversation_id &&
        conversationId() &&
        parsed.conversation_id !== conversationId()
      ) {
        return null;
      }
      return parsed;
    } catch {
      return null;
    }
  }

  function assistantDeltaFromBoundary() {
    const boundary = loadAssistantBoundary();
    const current = utf8Tail(conversationSurfaceText(), 64 * 1024);
    if (!boundary || !current) {
      return {
        content: "",
        strategy: "no_boundary",
        boundary_present: Boolean(boundary),
        main_text_chars: current.length,
      };
    }

    const userText = String(boundary.user_text || "").trim();
    const anchor = String(boundary.before_tail || "").trim();
    if (anchor) {
      const anchorIndex = current.lastIndexOf(anchor);
      if (anchorIndex >= 0) {
        let delta = current.slice(anchorIndex + anchor.length).trim();
        if (userText && delta.startsWith(userText)) {
          delta = delta.slice(userText.length).trim();
        }
        if (delta) {
          return {
            content: delta,
            strategy: "before_tail_anchor",
            boundary_present: true,
            main_text_chars: current.length,
          };
        }
      }
    }

    if (userText) {
      const searchStart = Math.max(0, current.length - 24 * 1024);
      const userIndex = current.indexOf(userText, searchStart);
      if (userIndex >= 0) {
        const afterUser = current.slice(userIndex + userText.length).trim();
        if (afterUser) {
          return {
            content: afterUser,
            strategy: "user_text_boundary",
            boundary_present: true,
            main_text_chars: current.length,
          };
        }
      }
    }

    return {
      content: "",
      strategy: "boundary_not_found",
      boundary_present: true,
      main_text_chars: current.length,
    };
  }

  function generationInProgress() {
    return Boolean(
      document.querySelector('[data-testid="stop-button"]') ||
      [...document.querySelectorAll("button")].some((button) =>
        /stop generating|停止生成|停止/i.test(
          [
            button.getAttribute("aria-label") || "",
            button.getAttribute("title") || "",
          ].join(" "),
        ),
      )
    );
  }

  function resetSuccessToReady(delay = 1800) {
    clearTimeout(successResetTimer);
    successResetTimer = setTimeout(() => {
      setState("idle", "Power · 点击复制续聊信息");
    }, delay);
  }

  async function completeOneClickHandoff() {
    setState("busy", "正在准备复制续聊信息…");
    const capture = assistantCapture();
    const response = await external({
      type: "POWER_PAGE_CLICK",
      pendingUser: pendingUserCapture(),
      emergencyRecentContext: await emergencyRecentConversationCapture(),
      assistantTail: capture.tail,
      assistantCaptureDiagnostic: capture.diagnostic,
      context: context(),
    });
    applyResponse(response);

    if (
      response?.ok &&
      (response?.data?.handoffCopied || response?.data?.localContinuationCopied)
    ) {
      showToast("续聊信息已复制。请打开新 Chat 后粘贴发送。");
      resetSuccessToReady();
    } else if (
      response?.ok &&
      response?.data?.state !== "degraded" &&
      response?.data?.state !== "error"
    ) {
      setState("error", "未能安全生成续聊信息");
      showToast("未复制续聊信息，请重试。", true);
    }

    oneClickTransaction = null;
    return response;
  }

  function turnRole(node) {
    const explicit =
      node.getAttribute?.("data-message-author-role") ||
      node.querySelector?.("[data-message-author-role]")?.getAttribute?.(
        "data-message-author-role"
      );
    if (explicit === "user" || explicit === "assistant") return explicit;

    const labelText = [
      ...(node.querySelectorAll?.("h1,h2,h3,h4,h5,h6,[class*='sr-only']") || []),
    ]
      .map((label) => (label.textContent || "").trim())
      .join(" ");
    if (/\b(chatgpt|assistant)\b\s*(said|says)?|chatgpt\s*(说|回复)/i.test(labelText)) {
      return "assistant";
    }
    if (/\b(you|user)\b\s*(said|says)?|(^|\s)你\s*(说|提问)/i.test(labelText)) {
      return "user";
    }

    const markdown = node.querySelector?.(".markdown,[class*='markdown']");
    if (markdown) return "assistant";
    return null;
  }

  function canonicalTurn(node) {
    return (
      node?.closest?.("[data-testid^='conversation-turn-']") ||
      node?.closest?.("article") ||
      node
    );
  }

  function uniqueNodes(nodes) {
    const out = [];
    const seen = new Set();
    for (const node of nodes) {
      if (!node || seen.has(node)) continue;
      seen.add(node);
      out.push(node);
    }
    return out;
  }

  function assistantCandidates() {
    const explicitAssistant = [
      ...document.querySelectorAll('[data-message-author-role="assistant"]'),
    ].map(canonicalTurn);

    const turnContainers = [
      ...document.querySelectorAll("[data-testid^='conversation-turn-']"),
    ];
    const roleAssistant = turnContainers
      .filter((node) => turnRole(node) === "assistant");

    const mainMarkdown = [
      ...document.querySelectorAll("main .markdown"),
    ]
      .map(canonicalTurn)
      .filter((node) => turnRole(node) !== "user");

    return uniqueNodes([
      ...explicitAssistant,
      ...roleAssistant,
      ...mainMarkdown,
    ]);
  }

  function assistantTurnText(node) {
    const explicit = node.matches?.('[data-message-author-role="assistant"]')
      ? node
      : node.querySelector?.('[data-message-author-role="assistant"]');
    if (explicit) {
      const text = (explicit.innerText || explicit.textContent || "").trim();
      if (text) return text;
    }

    let markdownNodes = [
      ...(node.querySelectorAll?.(".markdown") || []),
    ];
    if (!markdownNodes.length) {
      markdownNodes = [
        ...(node.querySelectorAll?.("[class*='markdown']") || []),
      ];
    }
    const markdownParts = markdownNodes
      .map((part) => (part.innerText || part.textContent || "").trim())
      .filter(Boolean);
    if (markdownParts.length) return [...new Set(markdownParts)].join("\n\n");

    return (node.innerText || node.textContent || "").trim();
  }

  function assistantCaptureDiagnostic(candidateCount, delta = null) {
    return {
      turn_containers: document.querySelectorAll(
        "[data-testid^='conversation-turn-']"
      ).length,
      explicit_assistant: document.querySelectorAll(
        '[data-message-author-role="assistant"]'
      ).length,
      explicit_user: document.querySelectorAll(
        '[data-message-author-role="user"]'
      ).length,
      main_markdown: document.querySelectorAll("main .markdown").length,
      main_markdown_loose: document.querySelectorAll(
        "main [class*='markdown']"
      ).length,
      assistant_candidates: candidateCount,
      boundary_present: Boolean(delta?.boundary_present),
      boundary_strategy: String(delta?.strategy || "none"),
      main_text_chars: Number(delta?.main_text_chars || 0),
      generation_in_progress: generationInProgress(),
    };
  }

  function assistantCapture() {
    const delta = assistantDeltaFromBoundary();
    if (delta.content) {
      const content = utf8Clip(delta.content);
      const diagnostic = assistantCaptureDiagnostic(0, delta);
      return {
        tail: content
          ? {
              content: "[assistant-recent-context]\n" + content,
              message_count: 1,
              generation_in_progress: diagnostic.generation_in_progress,
            }
          : null,
        diagnostic,
      };
    }

    const candidates = assistantCandidates();
    const messages = [
      ...new Set(
        candidates
          .map((node) => assistantTurnText(node))
          .filter(Boolean)
      ),
    ].slice(-4);
    const diagnostic = assistantCaptureDiagnostic(candidates.length, delta);

    if (!messages.length) return { tail: null, diagnostic };

    const content = utf8Clip(
      messages
        .map((text, index) => "[assistant-turn-" + (index + 1) + "]\n" + text)
        .join("\n\n"),
    );
    return {
      tail: content
        ? {
            content,
            message_count: messages.length,
            generation_in_progress: diagnostic.generation_in_progress,
          }
        : null,
      diagnostic,
    };
  }

  async function emergencyFallbackTurnId(role, content) {
    const digest = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(String(role || "") + "\n" + String(content || ""))
    );
    const bytes = new Uint8Array(digest).slice(0, 12);
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return "local_sha256_" + btoa(binary)
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/g, "");
  }

  function userTurnText(node) {
    const explicit = node.matches?.('[data-message-author-role="user"]')
      ? node
      : node.querySelector?.('[data-message-author-role="user"]');
    if (explicit) {
      const text = (explicit.innerText || explicit.textContent || "").trim();
      if (text) return text;
    }
    return (node.innerText || node.textContent || "").trim();
  }

  function cleanEmergencySurfaceContent(role, raw) {
    let value = String(raw || "").trim();
    if (!value) return "";
    if (role === "assistant") {
      const noiseMarkers = [
        "\nChatGPT 可能会出错。请核查重要信息。",
        "\nChatGPT can make mistakes. Check important info.",
        "\n最新一条回复",
      ];
      for (const marker of noiseMarkers) {
        const index = value.indexOf(marker);
        if (index >= 0) value = value.slice(0, index).trim();
      }
    }
    return value
      .replace(/^\s*(?:纯文本|复制代码|Copy code|已分析|Analyzed)\s*$/gim, "")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function boundedEmergencyTurnContent(role, raw) {
    const cleaned = cleanEmergencySurfaceContent(role, raw);
    if (!cleaned) return { content: "", truncated: false };
    const maxBytes = 24 * 1024;
    const bytes = new TextEncoder().encode(cleaned).byteLength;
    return {
      content: bytes > maxBytes ? utf8Clip(cleaned, maxBytes) : cleaned,
      truncated: bytes > maxBytes,
    };
  }

  async function emergencyTurnFromNode(node, index) {
    const role = turnRole(node);
    if (role !== "user" && role !== "assistant") return null;
    const bounded = boundedEmergencyTurnContent(
      role,
      role === "assistant" ? assistantTurnText(node) : userTurnText(node),
    );
    const content = bounded.content;
    if (!content) return null;

    const explicit = node.matches?.("[data-message-author-role]")
      ? node
      : node.querySelector?.("[data-message-author-role]");
    const turnId =
      explicit?.getAttribute?.("data-message-id") ||
      node.getAttribute?.("data-message-id") ||
      node.getAttribute?.("data-testid") ||
      await emergencyFallbackTurnId(role, content);

    return {
      role,
      turnId: String(turnId || ("emergency_" + index)).slice(0, 240),
      content,
      truncated: bounded.truncated,
    };
  }

  function pairEmergencyRounds(items) {
    const rounds = [];
    let pendingUser = null;
    for (const item of items) {
      if (item?.role === "user") {
        pendingUser = item;
        continue;
      }
      if (item?.role === "assistant" && pendingUser) {
        rounds.push({
          user: pendingUser,
          assistant: item,
        });
        pendingUser = null;
      }
    }
    return rounds;
  }

  async function parseVisibleEmergencyRounds(text) {
    const value = String(text || "")
      .replace(/^\s*(?:分享|正在加载更早的消息…?|显示更多)\s*$/gim, "")
      .replace(/^\s*(?:思考了|Thought for)\s+[^\n]*$/gim, "")
      .trim();
    if (!value) return [];

    const markerRe =
      /(?:^|\n)\s*(你说：|You said:|ChatGPT 说：|ChatGPT said:)\s*/gi;
    const markers = [];
    let match;
    while ((match = markerRe.exec(value))) {
      markers.push({
        role: /ChatGPT/i.test(match[1]) ? "assistant" : "user",
        start: match.index,
        contentStart: markerRe.lastIndex,
      });
    }
    if (!markers.length) return [];

    const items = [];
    for (let index = 0; index < markers.length; index += 1) {
      const current = markers[index];
      const next = markers[index + 1];
      const bounded = boundedEmergencyTurnContent(
        current.role,
        value
          .slice(current.contentStart, next ? next.start : value.length)
          .replace(/^\s*(?:显示更多|分享)\s*$/gim, "")
          .trim(),
      );
      const content = bounded.content;
      if (!content) continue;
      items.push({
        role: current.role,
        turnId: await emergencyFallbackTurnId(current.role, content),
        content,
        truncated: bounded.truncated,
        completeness: "unknown",
      });
    }
    return pairEmergencyRounds(items).slice(-3);
  }

  async function emergencyRecentConversationCapture() {
    let quality = "structured";
    let nodes = [
      ...document.querySelectorAll("[data-testid^='conversation-turn-']"),
    ];

    if (!nodes.length) {
      quality = "role_nodes";
      nodes = uniqueNodes([
        ...document.querySelectorAll(
          '[data-message-author-role="user"],[data-message-author-role="assistant"]'
        ),
      ].map(canonicalTurn));
    }

    const rawItems = (
      await Promise.all(
        nodes.map((node, index) => emergencyTurnFromNode(node, index))
      )
    ).filter(Boolean);
    let rounds = pairEmergencyRounds(rawItems);

    if (!rounds.length) {
      const parsed = await parseVisibleEmergencyRounds(conversationSurfaceText());
      if (parsed.length) {
        quality = "degraded_surface";
        rounds = parsed;
      } else {
        quality = "unavailable";
      }
    }

    const selected = rounds.slice(-3);
    return {
      rounds: selected,
      capture_quality: quality,
      overflowed: rounds.length > selected.length,
      captured_at: Date.now(),
    };
  }

  function looksLikeLocalEmergencyText(value) {
    const text = String(value || "");
    if (!/\[memory-v5-local-emergency\]/.test(text)) return false;
    return (
      /\[memory-v5-emergency-id:[^\]]+\]/.test(text) ||
      /@EmergencyId\s+\S+/.test(text) ||
      /【本地未同步用户请求】/.test(text) ||
      /这是本地(?:应急续聊|续聊恢复)包/.test(text)
    );
  }

  function pendingUserCapture() {
    const userTurns = [
      ...document.querySelectorAll('[data-message-author-role="user"]'),
    ];
    let boundaryIndex = -1;
    let boundary = "unknown";
    for (let index = userTurns.length - 1; index >= 0; index -= 1) {
      const text = (
        userTurns[index].innerText ||
        userTurns[index].textContent ||
        ""
      ).trim();
      CONTROL_SYNC_RE.lastIndex = 0;
      if (CONTROL_SYNC_RE.test(text)) {
        boundaryIndex = index;
        boundary = "memory_control_save";
        break;
      }
      if (
        /\[memory-v5-handoff:[A-Za-z0-9_-]+\]/.test(text) &&
        /\[memory-v5-lane:lane_[A-Za-z0-9_-]+\]/.test(text)
      ) {
        boundaryIndex = index;
        boundary = "memory_v5_handoff";
        break;
      }
      if (looksLikeLocalEmergencyText(text)) {
        boundaryIndex = index;
        boundary = "memory_v5_local_emergency";
        break;
      }
    }

    if (boundaryIndex < 0) {
      return {
        boundary,
        items: [],
        overflowed: false,
      };
    }

    const items = [];
    for (let index = boundaryIndex + 1; index < userTurns.length; index += 1) {
      const node = userTurns[index];
      const content = (
        node.innerText ||
        node.textContent ||
        ""
      ).trim();
      if (!content) continue;
      items.push({
        turnId:
          node.getAttribute?.("data-message-id") ||
          node.closest?.("[data-testid^='conversation-turn-']")?.getAttribute?.("data-testid") ||
          "local_" + index,
        content: utf8Clip(content, 10 * 1024),
      });
      if (items.length >= 50) break;
    }

    return {
      boundary,
      items,
      overflowed: userTurns.length - boundaryIndex - 1 > items.length,
    };
  }

  function external(message) {
    return new Promise((resolve) => {
      try {
        if (!globalThis.chrome?.runtime?.sendMessage) {
          resolve({ ok: false, error: "external_runtime_unavailable" });
          return;
        }
        chrome.runtime.sendMessage(
          EXTENSION_ID,
          { namespace: "memory-v5-power", pageVersion: VERSION, ...message },
          (response) => {
            const lastError = chrome.runtime.lastError;
            if (lastError) {
              resolve({ ok: false, error: lastError.message || "external_message_failed" });
              return;
            }
            resolve(response || { ok: false, error: "empty_external_response" });
          }
        );
      } catch (error) {
        resolve({ ok: false, error: String(error?.message || error) });
      }
    });
  }

  const root = document.createElement("div");
  root.id = ROOT_ID;
  Object.assign(root.style, {
    position: "fixed",
    right: "18px",
    top: "52%",
    zIndex: "2147483646",
    pointerEvents: "auto",
  });

  const shadow = root.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = `
    :host { all: initial; }
    button {
      width: 30px; height: 30px; border: 0; border-radius: 10px;
      box-shadow: 0 6px 18px rgba(15,23,42,.22); cursor: pointer;
      font: 700 15px/30px system-ui,-apple-system,"Segoe UI",sans-serif;
      text-align: center; user-select: none; touch-action: none;
      transition: transform .12s ease, opacity .12s ease;
    }
    button:hover { transform: scale(1.06); }
    button[data-state="idle"] { background:#22c55e; color:#fff; }
    button[data-state="locked"] { background:#15803d; color:#fff; }
    button[data-state="busy"] { background:#2563eb; color:#fff; }
    button[data-state="auth"] { background:#d97706; color:#fff; }
    button[data-state="degraded"] { background:#b45309; color:#fff; }
    button[data-state="error"] { background:#dc2626; color:#fff; }
  `;
  const button = document.createElement("button");
  button.type = "button";
  button.dataset.state = "idle";
  button.textContent = "•";
  button.title = "Power · 点击复制续聊信息";

  shadow.append(style, button);
  document.documentElement.appendChild(root);

  function setState(state, title = "") {
    const next = ["idle", "locked", "busy", "auth", "degraded", "error"].includes(state)
      ? state
      : "idle";
    button.dataset.state = next;
    button.textContent =
      next === "locked" ? "✓" :
      next === "busy" ? "…" :
      next === "auth" ? "↗" :
      next === "degraded" ? "!" :
      next === "error" ? "!" : "•";
    button.title = title || (
      next === "locked" ? "续聊信息已复制" :
      next === "busy" ? "正在准备续聊信息" :
      next === "auth" ? "点击连接 Memory V5" :
      next === "degraded" ? "服务暂不可用 · 点击使用应急续聊" :
      next === "error" ? "Memory V5 发生错误" :
      "Power · 点击复制续聊信息"
    );
  }

  function showToast(text, error = false) {
    if (!text) return;
    let toast = document.getElementById(TOAST_ID);
    if (!toast) {
      toast = document.createElement("div");
      toast.id = TOAST_ID;
      Object.assign(toast.style, {
        position: "fixed",
        right: "18px",
        bottom: "88px",
        zIndex: "2147483647",
        padding: "10px 13px",
        borderRadius: "10px",
        color: "#fff",
        font: '13px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif',
        boxShadow: "0 6px 24px rgba(15,23,42,.22)",
        maxWidth: "360px",
        pointerEvents: "none",
      });
      document.documentElement.appendChild(toast);
    }
    toast.style.background = error ? "#7f1d1d" : "#111827";
    toast.textContent = String(text);
    toast.style.display = "block";
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      if (toast?.isConnected) toast.style.display = "none";
    }, 3400);
  }

  function applyResponse(response) {
    if (!response?.ok) {
      if (response?.degraded) {
        setState("degraded", "Memory V5 服务暂时不可用");
        showToast("Memory V5 暂时不可用，稍后刷新页面重试。");
        return;
      }
      setState("error", response?.error || "Memory V5 连接失败");
      return;
    }
    const data = response.data || {};
    if (data.state) setState(data.state, data.title || "");
    if (data.toast) showToast(data.toast, Boolean(data.toastError));
  }

  async function refreshState() {
    const response = await external({
      type: "POWER_PAGE_STATUS",
      context: context(),
    });
    applyResponse(response);
  }

  function latestControlSyncKey() {
    const userTurns = [
      ...document.querySelectorAll('[data-message-author-role="user"]'),
    ];
    for (let index = userTurns.length - 1; index >= 0; index -= 1) {
      const text = (
        userTurns[index].innerText ||
        userTurns[index].textContent ||
        ""
      ).trim();
      const matches = [...text.matchAll(CONTROL_SYNC_RE)]
        .map((match) => match[1])
        .filter((key) => !String(key || "").startsWith(POWER_SYNC_PREFIX));
      if (matches.length) return matches[matches.length - 1];
    }

    const text = conversationSurfaceText();
    const matches = [...text.matchAll(CONTROL_SYNC_RE)]
      .map((match) => match[1])
      .filter((key) => !String(key || "").startsWith(POWER_SYNC_PREFIX));
    return matches.length ? matches[matches.length - 1] : "";
  }

  function scheduleControlSync(delay = 500) {
    if (syncTimer) return;
    syncTimer = setTimeout(() => {
      syncTimer = null;
      const syncKey = latestControlSyncKey();
      if (
        !syncKey ||
        syncKey === completedSyncKey ||
        syncKey === failedSyncKey
      ) return;

      if (syncKey !== activeSyncKey) {
        activeSyncKey = syncKey;
        syncAttempts = 0;
      }

      pollControlSync().catch(() => {
        if (activeSyncKey && syncAttempts < 3) scheduleControlSync(3000);
      });
    }, delay);
  }

  async function pollControlSync() {
    const syncKey = activeSyncKey;
    if (
      !syncKey ||
      syncKey === completedSyncKey ||
      syncKey === failedSyncKey
    ) return;

    if (generationInProgress()) {
      scheduleControlSync(1500);
      return;
    }

    syncAttempts += 1;
    const response = await external({
      type: "POWER_CONTROL_SYNC",
      idempotencyKey: syncKey,
      context: context(),
    });

    const oneClickSync = syncKey.startsWith(POWER_SYNC_PREFIX);

    if (!response?.ok) {
      const error = String(response?.error || "sync_failed");
      if (response?.degraded) {
        failedSyncKey = syncKey;
        activeSyncKey = "";
        if (oneClickSync) {
          await forceOneClickEmergency(
            oneClickTransaction?.snapshot || await oneClickRecoverySnapshot(),
            "save_sync_unavailable:" + error
          );
        } else {
          setState("degraded", "Memory V5 服务暂时不可用");
          showToast("Memory V5 暂时不可用，稍后刷新页面重试。");
        }
        return;
      }
      const retryable =
        /network_timeout|failed to fetch|external_message_failed|empty_external_response|external_runtime_unavailable|companion_request_failed/i.test(error);
      if (!retryable || syncAttempts >= 3) {
        failedSyncKey = syncKey;
        activeSyncKey = "";
        if (oneClickSync && retryable) {
          await forceOneClickEmergency(
            oneClickTransaction?.snapshot || await oneClickRecoverySnapshot(),
            "save_sync_failed:" + error
          );
        } else {
          oneClickTransaction = null;
          setState("error", "Memory V5 保存同步失败");
          showToast("保存同步失败：" + error, true);
        }
        return;
      }
      scheduleControlSync(3000);
      return;
    }

    if (oneClickSync && response?.data?.completed) {
      completedSyncKey = syncKey;
      failedSyncKey = "";
      activeSyncKey = "";
      syncAttempts = 0;

      if (!response?.data?.canonicalReady) {
        oneClickTransaction = null;
        setState("error", "保存完成，但任务身份未能安全锁定");
        showToast("未生成续聊内容：任务身份仍不明确，Power 已停止而不是猜测。", true);
        return;
      }

      await completeOneClickHandoff();
      return;
    }

    applyResponse(response);
    if (response?.data?.syncTerminal) {
      failedSyncKey = syncKey;
      activeSyncKey = "";
      if (oneClickSync) {
        oneClickTransaction = null;
        setState("error", "保存没有完成");
        showToast("Memory V5 没有确认保存成功；未复制续聊信息。请重新点击 Power。", true);
      }
      return;
    }
    if (
      response?.data?.state === "error" ||
      response?.data?.state === "auth"
    ) {
      failedSyncKey = syncKey;
      activeSyncKey = "";
      if (oneClickSync) oneClickTransaction = null;
      return;
    }
    if (response?.data?.completed) {
      completedSyncKey = syncKey;
      failedSyncKey = "";
      activeSyncKey = "";
      syncAttempts = 0;
      return;
    }

    if (syncAttempts >= 3) {
      failedSyncKey = syncKey;
      activeSyncKey = "";
      if (oneClickSync) {
        oneClickTransaction = null;
        setState("error", "保存没有完成");
        showToast("Memory V5 没有确认保存成功；未复制续聊信息。请重新点击 Power。", true);
      } else {
        setState("idle", "Memory V5 保存同步超时");
        showToast("保存同步超时；刷新当前 Chat 后可重试。", true);
      }
      return;
    }
    scheduleControlSync(3000);
  }

  function ensureDraftTurnId() {
    if (!draftTurnId) draftTurnId = "page_" + crypto.randomUUID();
    return draftTurnId;
  }

  async function captureSend(source) {
    const text = promptText();
    if (!text) return null;
    const now = Date.now();
    if (lastSend.text === text && now - lastSend.at < 1200) {
      return { ok: true, deduped: true };
    }
    lastSend = { text, at: now };
    const turnId = ensureDraftTurnId();
    storeAssistantBoundary(text, turnId);
    draftTurnId = "";
    const response = await external({
      type: "POWER_PAGE_SEND",
      text,
      turnId,
      source,
      context: context(),
    });
    applyResponse(response);
    return response;
  }

  function clampTop(y) {
    return Math.max(12, Math.min(window.innerHeight - 42, y));
  }

  try {
    const saved = JSON.parse(localStorage.getItem(POSITION_KEY) || "null");
    if (saved && Number.isFinite(saved.top)) root.style.top = clampTop(saved.top) + "px";
  } catch {}

  button.addEventListener("pointerdown", (event) => {
    drag = {
      id: event.pointerId,
      y: event.clientY,
      top: root.getBoundingClientRect().top,
      moved: false,
    };
    button.setPointerCapture?.(event.pointerId);
  }, { signal: abort.signal });

  button.addEventListener("pointermove", (event) => {
    if (!drag || drag.id !== event.pointerId) return;
    const dy = event.clientY - drag.y;
    if (Math.abs(dy) > 4) drag.moved = true;
    root.style.top = clampTop(drag.top + dy) + "px";
  }, { signal: abort.signal });

  button.addEventListener("pointerup", (event) => {
    if (!drag || drag.id !== event.pointerId) return;
    const moved = drag.moved;
    drag = null;
    try {
      localStorage.setItem(POSITION_KEY, JSON.stringify({
        top: root.getBoundingClientRect().top,
      }));
    } catch {}
    if (moved) button.dataset.suppressClick = "1";
  }, { signal: abort.signal });

  button.addEventListener("pointercancel", () => { drag = null; }, { signal: abort.signal });

  document.addEventListener("input", (event) => {
    if (!isPromptTarget(event.target)) return;
    if (promptText()) ensureDraftTurnId();
  }, { capture: true, signal: abort.signal });

  document.addEventListener("keydown", (event) => {
    if (
      event.key === "Enter" &&
      !event.shiftKey &&
      !event.ctrlKey &&
      !event.metaKey &&
      !event.altKey &&
      !event.isComposing &&
      isPromptTarget(event.target)
    ) {
      captureSend("enter");
    }
  }, { capture: true, signal: abort.signal });

  document.addEventListener("click", (event) => {
    if (isSendButton(event.target)) captureSend("send_click");
  }, { capture: true, signal: abort.signal });

  document.addEventListener("submit", (event) => {
    if (event.target?.contains?.(promptElement())) captureSend("form_submit");
  }, { capture: true, signal: abort.signal });

  button.addEventListener("click", async (event) => {
    if (
      button.dataset.state === "busy" ||
      button.dataset.state === "locked"
    ) return;
    if (button.dataset.suppressClick === "1") {
      button.dataset.suppressClick = "";
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    setState("busy", "正在准备续聊信息…");
    await completeOneClickHandoff();
  }, { signal: abort.signal });

  const syncSurface =
    document.querySelector("main") ||
    document.querySelector('[role="main"]') ||
    document.body ||
    document.documentElement;
  if (syncSurface) {
    syncObserver = new MutationObserver(() => scheduleControlSync());
    syncObserver.observe(syncSurface, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }

  const onRoute = () => {
    refreshState().catch(() => {});
    scheduleControlSync();
  };
  window.addEventListener("popstate", onRoute, { signal: abort.signal });

  function stop() {
    try { abort.abort(); } catch {}
    clearTimeout(toastTimer);
    clearTimeout(syncTimer);
    clearTimeout(successResetTimer);
    oneClickTransaction = null;
    syncObserver?.disconnect?.();
    document.getElementById(ROOT_ID)?.remove();
    document.getElementById(TOAST_ID)?.remove();
    if (window[AGENT_KEY]?.version === VERSION) delete window[AGENT_KEY];
  }

  window[AGENT_KEY] = { version: VERSION, stop };
  refreshState().catch(() => {
    setState("error", "Memory V5 连接失败");
  });
  scheduleControlSync(0);
})();
