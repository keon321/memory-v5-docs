function runtime(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response ?? { ok: false, error: "empty_response" });
    });
  });
}

const auth = document.getElementById("auth");
const detail = document.getElementById("detail");
const message = document.getElementById("message");
const login = document.getElementById("login");
const logout = document.getElementById("logout");
const version = document.getElementById("version");

version.textContent = "v" + chrome.runtime.getManifest().version;

async function refresh() {
  const result = await runtime({ type: "POWER_AUTH_STATUS" });
  if (!result?.ok) {
    auth.textContent = "TaskOnward 不可用";
    detail.textContent = result?.error || "无法读取登录状态";
    login.disabled = false;
    logout.disabled = true;
    return;
  }

  if (!result.data.configured) {
    auth.textContent = "TaskOnward 尚未配置";
    detail.textContent = "当前 Beta 配置不可用。";
    login.disabled = true;
    logout.disabled = true;
    return;
  }

  if (result.data.authenticated) {
    auth.textContent = "已连接 TaskOnward";
    detail.textContent = "可以在 ChatGPT 中正常使用。";
    login.disabled = true;
    logout.disabled = false;
  } else {
    auth.textContent = "尚未登录";
    detail.textContent = "首次使用只需登录一次。";
    login.disabled = false;
    logout.disabled = true;
  }
}

login.addEventListener("click", async () => {
  login.disabled = true;
  message.textContent = "正在打开登录…";
  const result = await runtime({ type: "POWER_AUTH_LOGIN" });
  message.textContent = result?.ok
    ? "登录完成。"
    : (result?.error || "登录失败。");
  await refresh();
});

logout.addEventListener("click", async () => {
  logout.disabled = true;
  const result = await runtime({ type: "POWER_AUTH_LOGOUT" });
  message.textContent = result?.ok ? "已退出。" : (result?.error || "退出失败。");
  await refresh();
});

refresh().catch(() => {
  auth.textContent = "TaskOnward 不可用";
  detail.textContent = "状态读取失败。";
});
