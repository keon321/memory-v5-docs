(() => {
  const ROOT_ID = "memory-v5-power-root";
  const VERSION = "0.7.7";

  // Dormant stub: normal ChatGPT use must not enter TaskOnward code paths.
  // The only persistent behavior is this button's own click listener.
  document.getElementById(ROOT_ID)?.remove();

  const root = document.createElement("div");
  root.id = ROOT_ID;
  Object.assign(root.style, {
    position: "fixed",
    right: "18px",
    top: "52%",
    zIndex: "2147483646",
    pointerEvents: "auto",
  });

  const shadow = root.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = `
    :host { all: initial; }
    button {
      width: 30px; height: 30px; border: 0; border-radius: 10px;
      box-shadow: 0 6px 18px rgba(15,23,42,.22); cursor: pointer;
      font: 700 15px/30px system-ui,-apple-system,"Segoe UI",sans-serif;
      text-align: center; user-select: none;
    }
    button[data-state="idle"] { background:#22c55e; color:#fff; }
    button[data-state="busy"] { background:#2563eb; color:#fff; cursor:wait; }
    button[data-state="locked"] { background:#15803d; color:#fff; }
    button[data-state="degraded"] { background:#d97706; color:#fff; }
    button[data-state="error"] { background:#dc2626; color:#fff; }
    .status {
      position:absolute; right:38px; top:-3px; width:max-content; max-width:280px;
      padding:7px 9px; border-radius:8px; background:#0f172a; color:#fff;
      font:500 12px/1.35 system-ui,-apple-system,"Segoe UI",sans-serif;
      box-shadow:0 6px 18px rgba(15,23,42,.22); display:none;
    }
    .status[data-show="1"] { display:block; }
  `;

  const button = document.createElement("button");
  button.type = "button";
  button.dataset.state = "idle";
  button.textContent = "P";
  button.title = "TaskOnward · 点击复制续聊信息";
  button.setAttribute("aria-label", "TaskOnward · 点击复制续聊信息");

  const status = document.createElement("div");
  status.className = "status";
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");

  shadow.append(style, button, status);
  (document.documentElement || document.body).appendChild(root);

  let hideTimer = null;

  function showStatus(ui) {
    const state = String(ui?.state || "idle");
    const label = String(ui?.label || ui?.title || "TaskOnward");
    const detail = String(ui?.detail || ui?.toast || "").trim();
    button.dataset.state = state;
    button.textContent = state === "busy" ? "…" : state === "error" ? "!" : state === "locked" ? "✓" : "P";
    button.title = detail ? label + " · " + detail : label;
    status.textContent = detail ? label + " · " + detail : label;
    status.dataset.show = "1";
    if (hideTimer) clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      status.dataset.show = "0";
      if (button.dataset.state !== "busy") {
        button.dataset.state = "idle";
        button.textContent = "P";
      }
    }, 4200);
  }

  button.addEventListener("click", () => {
    if (button.dataset.state === "busy") return;
    button.dataset.state = "busy";
    button.textContent = "…";
    status.textContent = "TaskOnward 正在读取当前对话…";
    status.dataset.show = "1";

    chrome.runtime.sendMessage(
      { type: "POWER_ACTIVATE", pageVersion: VERSION },
      (response) => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          showStatus({
            state: "error",
            label: "TaskOnward 暂不可用",
            detail: "扩展通信失败，请重试。",
          });
          return;
        }
        if (!response?.ok) {
          showStatus({
            state: response?.degraded ? "degraded" : "error",
            label: "TaskOnward 暂不可用",
            detail: "请稍后重试。",
          });
          return;
        }
        showStatus(response.data || { state: "idle", label: "TaskOnward" });
      }
    );
  });
})();
